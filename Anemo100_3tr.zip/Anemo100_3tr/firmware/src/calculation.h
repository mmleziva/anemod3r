
#ifndef _CALCULATION_H    /* Guard against multiple inclusion */
#define _CALCULATION_H
#include "definitions.h"
#include "anals.h"
#include <math.h>
#include <stdio.h>
#define TRIGPER (PR5+1) //ADC trigger timer
#define NPACK 20   
extern char rxData;
void inicalc(void);
void calc(void);
extern float dt[NREC];
extern bool RESX, RESY;
#endif /*_CALCULATION_H*/
