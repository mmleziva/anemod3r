#define  M_PI 3.142  //t
#define N 6
#define XMAX (128-1)
#define INIX 6
#define K 2
#include "anafun.h"


int u1, u2,ua,ub, x,ns,xa,xb;
int j,nt,wwM,ed;
float Sx,Sy;
float ret,Amp1,Amp2,Ampre, Coef,xcor;
bool SIGN1,SIGN2,SIGNA, SCROSS;
uint16_t PR2mem,OC1RSmem,OC2Rmem,OC5RSmem,OC9Rmem,OC14RSmem,OC10Rmem;

//int wh,ww;
//int whmem,wwmem;
float wh,ww;
//float whmem,wwmem;

void dFrekv(int16_t df_Hz)
{
          int16_t dOCR;
          dOCR= -((3*df_Hz)/160);  
          PR2= PR2mem+ (dOCR<<1);
          OC1RS= OC1RSmem+ dOCR;
          OC2R= OC2Rmem+ dOCR;
          OC5RS= OC5RSmem+ dOCR;
          OC9R= OC9Rmem+ dOCR;
          OC14RS= OC14RSmem+ dOCR;
          OC10R= OC10Rmem+ dOCR;
          wh= (float)(PR2+1)/(2*(PR5+1)); //number of half wave samples
          ww= 2*wh;                //whole wave samples
}

void iniAnafun(void)
{
   PR2mem= PR2;
   OC1RSmem= OC1RS;
   OC2Rmem= OC2R;
   OC5RSmem= OC5RS;
   OC9Rmem= OC9R;
   OC14RSmem= OC14RS;
   OC10Rmem= OC10R;
   wh= (PR2+1)/(2*(PR5+1)); //number of half wave samples
   ww= 2*wh;                //whole wave samples
  // wwM= ww+ INIX;
   Coef= ww/ M_PI; 
}

uint16_t aver(int16_t *p, harm *q)// The ADC samples pointed p are processed into the structure pointed  q
{
 errors err;    
 err.u=0;
 long int sumplus,suminus; //areas of positive and negative half-waves
// bool XOVER= false;
 wwM= ww+ INIX;
 nt=0;
 x=0;
 SCROSS= false;
 sumplus=0;
 suminus=0;
 ns=0;
 u2=p[x];//u1 and u2 are neighboring values, measured by ADC
 SIGN2=(u2<0);
 while(((x< wwM )||(nt<1))&& (x< XMAX))
 {
     u1=u2;
     x++;
     ns++;
     SIGN1=SIGN2;
     u2=p[x];
     SIGN2=(u2<0);
     if(x <= (ww))
     {
      if(SIGN2)suminus +=u2;
      else sumplus +=u2;
     }
     if(SIGN1 != SIGN2)
     {        
          if(SCROSS)
          {
           xb= x;
           ub=u2;
          }
          else
          {
           if(ns >2)
           {
               ua= u1;   
               ub= u2;   
               SIGNA= SIGN1;   
               xa= x-1;
               xb= x;
               SCROSS= true;
           }           
         }  
         ns=0;       
     }
     if((ns>3) && SCROSS)
     {
       SCROSS=0; 
       if(SIGNA && !SIGN2)
       {
         nt++;  
         xcor = xa + ((float)(ua * (xb-xa)))/(ua - ub); //corrected x coordinate 
         q->ph1= xcor;
       }
      }
 }
 err.CROSSZERO= (nt<1);
 err.TOOTHS= (nt>2);
 //XOVER= ((nt<1)||(nt>2));
// if(!XOVER)
 {
  Amp1= sumplus /Coef; //an ampllitude of positive halfwave
  Amp2= suminus /Coef; //an ampllitude of negative halfwave
  Ampre= (Amp1 - Amp2)/2;//an average amplitude
 // q->Amp= abs(Ampre);
  q->Amp= Ampre;
  q->dAmp= (Amp1 + Amp2)/2;// zero value correction
  if(q->Amp == 0)
      err.ZERODIV= true;
  if(Ampre < K*abs(q->dAmp))
      err.ASYMETRIC = true;
 }
 return err.u;
}
 
float LeastSquars(int16_t *p, harm *q)//the least squares method
{//The measured samples marked p on the linear part of the sine close to zero are processed by this method and specify the originally obtained phase
 float corx;
  x= (int)(q->ph1)-N/2;
 if(x<0)x=0;
 Sx=0;
 Sy=0;
 for(j=0;j<N;j++)
 {
  Sx +=x;
  Sy += p[x]-(q->dAmp);
  x++;
 }
 corx= Sy*Coef/(2* q->Amp);
  q->pha= (Sx - corx)/N;   
 return q->pha;
}
