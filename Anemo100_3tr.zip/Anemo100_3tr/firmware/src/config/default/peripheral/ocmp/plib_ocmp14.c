/*******************************************************************************
  Output Compare OCMP14 Peripheral Library (PLIB)

  Company:
    Microchip Technology Inc.

  File Name:
    plib_ocmp14.c

  Summary:
    OCMP14 Source File

  Description:
    None

*******************************************************************************/

/*******************************************************************************
* Copyright (C) 2019 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/
#include "plib_ocmp14.h"

// *****************************************************************************

// *****************************************************************************
// Section: OCMP14 Implementation
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************


OCMP_OBJECT ocmp14Obj;

void OCMP14_Initialize (void)
{
    /*Setup OC14CON        */
    /*OCM         = 5        */
    /*OCTSEL       = 0        */
    /*OC32         = 0        */
    /*SIDL         = false    */

    OC14CON = 0x5;

    OC14R = 750;
    OC14RS = 0;

    IEC6SET = _IEC6_OC14IE_MASK;
}

void OCMP14_Enable (void)
{
    OC14CONSET = _OC14CON_ON_MASK;
}

void OCMP14_Disable (void)
{
    OC14CONCLR = _OC14CON_ON_MASK;
}


void OCMP14_CompareValueSet (uint16_t value)
{
    OC14R = value;
}

uint16_t OCMP14_CompareValueGet (void)
{
    return (uint16_t)OC14R;
}

void OCMP14_CompareSecondaryValueSet (uint16_t value)
{
    OC14RS = value;
}

uint16_t OCMP14_CompareSecondaryValueGet (void)
{
    return (uint16_t)OC14RS;
}

void OCMP14_CallbackRegister(OCMP_CALLBACK callback, uintptr_t context)
{
    ocmp14Obj.callback = callback;

    ocmp14Obj.context = context;
}

void OUTPUT_COMPARE_14_InterruptHandler (void)
{
    IFS6CLR = _IFS6_OC14IF_MASK;    //Clear IRQ flag

    if( (ocmp14Obj.callback != NULL))
    {
        ocmp14Obj.callback(ocmp14Obj.context);
    }
}

