#ifndef _DEBUG_H
#define _DEBUG_H

//#include "GenericTypeDefs.h"
//#include "Compiler.h"

#include "definitions.h"
//definice pinu pro debug
	//#include <p32xxxx.h>
	//#include <plib.h>
/*
#define DEBUG_DATA_TRIS	    (TRISCbits.TRISC7)
#define DEBUG_CLOCK			(LATCbits.LATC7)
#define DEBUG_CLOCK_TRIS	(TRISCbits.TRISC6)
#define DEBUG_DATA			(LATCbits.LATC6)
*/

#define DEBUG_DATA_TRIS	    (TRISFbits.TRISF6)
#define DEBUG_CLOCK			(LATFbits.LATF6)
#define DEBUG_CLOCK_TRIS	(TRISFbits.TRISF7)
#define DEBUG_DATA			(LATFbits.LATF7)



void delay_us(uint16_t delay);
void delay_ms(uint16_t delay);
void debug_send_byte(uint8_t byt);
void debug_print_hex_u8(uint8_t  byt);
void debug_print_hex_u16(uint16_t wrd);
void debug_print_hex_s16(uint16_t wrd);
void debug_print_hex_u32(uint32_t b);
void debug_print_str(char *s);
//void debug_print_str2(char *s);
void debug_print_dec(int wrd);
void debug_print_float(float b, uint8_t  des);
void debug_init(uint8_t stav);
#endif
