
//#include <GenericTypeDefs.h>
//#include "Compiler.h"
#include "debug.h"


//dat tu systeovou funkci

void delay_us(uint16_t delay)
{uint16_t j;
   for (j=0; j<delay; j++) { 
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();

       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();

       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();
       Nop();

   }
}

void delay_ms(uint16_t delay)
{ uint16_t i; 
  for (i=0; i<delay; i++)  delay_us(1000);
} 






uint8_t GBSTAV=0;

#define DEBUG 

#if defined(DEBUG)



void debug_init(uint8_t stav)
{
    
if (stav) {    
  DEBUG_DATA_TRIS=0;//vystup
  DEBUG_CLOCK_TRIS=0; //vystup  
}
else  {
 DEBUG_DATA_TRIS=1;
 DEBUG_CLOCK_TRIS=1;
}
GBSTAV=stav;    

}

//fce pro debug
void debug_send_byte(uint8_t byt)
{
uint8_t i,parita;
//uint8_t st;
if (!GBSTAV) return;
parita=0;
//if (byt&0x01) st=1; else st=0;

for (i=0; i<8; i++) {
                 DEBUG_CLOCK=0; 
                 delay_us(3);
                 if (byt&0x01) {DEBUG_DATA=1;DEBUG_CLOCK=1; parita++;}
                 else {DEBUG_DATA=0;DEBUG_CLOCK=1;}
                 byt=byt>>1;
				 delay_us(3);

                    }

 DEBUG_CLOCK=0;
 delay_us(3);
 
 if (parita&0x01)  {DEBUG_DATA=1;DEBUG_CLOCK=1;} else {DEBUG_DATA=0;DEBUG_CLOCK=1;}
 delay_us(3);
 DEBUG_CLOCK=0;
 delay_us(3);
 DEBUG_DATA=0;
 //delay_us(1);
}

void debug_print_hex_u8(uint8_t byt)
{uint8_t a,b;
a=byt&0x0f;
b=(byt&0xF0)>>4;
if (b>9) debug_send_byte(b+55);
else debug_send_byte(b+48);

if (a>9) debug_send_byte(a+55);
else debug_send_byte(a+48);
}


void debug_print_hex_u16(uint16_t wrd)
{
debug_print_hex_u8(wrd>>8);
debug_print_hex_u8(wrd);
}
void debug_print_hex_s16(uint16_t wrd)
{int t;


if (wrd&0x1000) {debug_send_byte('-');
      t=wrd&0x7fff;      
      wrd=0x7fff-t;
      
       
}
debug_print_hex_u8(wrd>>8);
debug_print_hex_u8(wrd);
}


//void debug_print_str2(uint8_t *s)
//{uint8_t i,len;

 //len=strlen(s);
 //for (i=0; i<len; i++) {debug_send_byte(s[i]);}
//}



void debug_print_dec( int prd)
{uint16_t i,f;
   int t;
uint16_t wrd;

//debug_print_str("\rctrprd:");
//debug_print_hex_u16(prd); 


if (prd&0x1000) {
//debug_print_str("\rsdsdsdsds");
     debug_send_byte('-');
      t=prd&0x7fff; 
      //t-=1;
      prd=0x8000-t;
      
      //wrd++;
}

wrd=(uint16_t)prd;
//debug_print_str("\r\nctr2:");
//debug_print_hex_u16(wrd); 

f=0;
if (wrd>=10000) {
    i=wrd/10000; 
    debug_send_byte(i+48);
    wrd=wrd%10000;
    f=1;
    //debug_send_byte('*'); 
}

if ((wrd>=1000) || f){
    i=wrd/1000;
    debug_send_byte(i+48);
    wrd=wrd%1000;
    f=1;
    //debug_send_byte('#'); 
}

if ((wrd>=100) || f){
    i=wrd/100;
    debug_send_byte(i+48);
    wrd=wrd%100;
    f=1; 
    //debug_send_byte('&'); 
}

if ((wrd>=10) || f){
    i=wrd/10;
    debug_send_byte(i+48);
    wrd=wrd%10;
     //debug_send_byte('$'); 
    
}

debug_send_byte(wrd+48);


}


void debug_print_hex_u32(uint32_t b)
{
debug_print_hex_u16(b>>16);
debug_print_hex_u16(b);
}

void debug_print_str(char *s)
{
 
uint16_t i;
uint16_t len;
 
 len=strlen(s);
 //if (len>500) len=500;
 //memcpypgm2ram(tempStr, s, len);
 for (i=0; i<len; i++) {debug_send_byte(*s++);}
}



void debug_print_float(float b, uint8_t des)
{
uint8_t i,j,id,zero,sgn,nuly;
char OString[30];
uint64_t exp;

uint64_t ccast;
uint64_t tccast,dccast;
//b=123.521;
//debug_print_str("\r\n konverze:");
//debug_print_hex_u8(des);
//debug_print_hex_u32(b);

//des=5;
//b=3.2;


id=0;
zero=0;//pro odstraneni nul pred cislem
for(i=0;i<sizeof(OString);i++) OString[i]=0x00;
sgn=0;
if (((float)b)<0) {OString[id++]='-'; b=b* -1; sgn=1;}

 
//zpracovani cele casti
exp=1000000000000; //vetsi cislo jak 100 tacu nebude
ccast=(long int)b; // mame prvni ccast
tccast=ccast;
dccast=ccast;
//debug_print_str("\r\n tccast:");
//debug_print_hex_u16(tccast);

for (i=0; i<13; i++) {
   j=ccast/exp;
  // debug_print_hex_u8(j);
   if (! ((!j) && (!zero)))  {OString[id++]=j+48; zero=1;
	//						  debug_send_byte(j+48);
                             }
  if (zero) ccast=ccast%exp;
  exp=exp/10;
   
}

if (!tccast) OString[id++]='0';
if (des) OString[id++]='.'; //tecka z desetinnkou

//debug_print_str("\r\n tail:");
nuly=0;
for (i=0; i<des; i++) {
         b=b-tccast; //zustanou desetinna mista
         b=b*10;
  //       debug_print_hex_u8(b);
         OString[id]=(uint8_t)b+48;		 
         if(OString[id]==48) nuly++;
         id++;
         tccast=b;
                      }  
                    
OString[id++]=0;
/*
debug_print_str("\r\n vysledek ccast:");
debug_print_hex_u16(tccast);
debug_print_hex_u16(dccast);
debug_print_str("-");
debug_print_hex_u8(nuly);
debug_print_str("-");
debug_print_hex_u8(des);
debug_print_str("-");
debug_print_hex_u8(sgn);
debug_print_str("-");
debug_print_hex_u8(id);

*/
//udelat kontorlu kdyby to bylo -0.0 v dusledku osekani desetinnych mist..

if (!dccast)  {
    if ((nuly==des) && (sgn)) {//vymazat znamenko
            //debug_print_str("\r\nrezeme");
            for (i=0; i<id; i++) {OString[i]=OString[i+1];}
     }          
}
//debug_print_str("\r\nvysledek:");
//vytisk
debug_print_str(&OString[0]);
}


#endif



