
#include "anals.h"
uint16_t ja,CYCLE,OSCSTART;
uint32_t auxstat;
bool TBUFUL,FL_MES ;
uint16_t *ptrAna;
#define NCANALS 6    
#define NR 7  //SAMPS=2^NR  
#define OS 80
//#define WAVES (2*NREC)

int16_t adcdma[NCANALS][2 * 128];
uint8_t ndma[2 * NCANALS]; //actual pointers in adcdma

void ADMApreset(void) {
    ADCDMAB = KVA_TO_PA((uint32_t) &adcdma); ; //adma addressing and turn virtual to physical memory
    ADCCNTB = KVA_TO_PA((uint32_t) &ndma);
}

inline void StartAD(void) 
{
   WDTCONbits.WDTCLRKEY = 0x5743;
   {     
    if (!CONTA)  //ADC finished and start enable
    {
        TMR5=0;
        TMR5_Start();
        CONTA= true;                //measurement is in progress
        ADCDSTATbits.DMAEN = 1; //t
        ADCDSTATbits.DMACEN = 1; //count enable
      //  ADCHS_ModulesEnable( ADCHS_MODULE0_MASK | ADCHS_MODULE1_MASK| ADCHS_MODULE2_MASK );//t
        ADCHS_ModulesEnable( ADCHS_MODULE2_MASK );//t
    }
   } 
} 

inline void OCMP_Clear(void)
{
    OCMP1_Disable ();
    OCMP2_Disable ();
    OCMP3_Disable ();
    OCMP4_Disable ();
    OCMP14_Disable ();
    OCMP9_Disable ();
}

inline void StopAD(void) 
{
    FL_MES= false;
   // LED2_Clear();//t
    {
     if(!NOCHANGE)
     {        
         /*
         //sample of one wavelenght  
        ptrAna= (uint16_t *) &(INPREGS[ADRANA].W);//pointer to modbus register
        for (ja = 0; ja < (SAMPSTER); ja++)
        {
           for (bj = 0; bj < NREC; bj++)
           {
             *ptrAna= adcdma[bj][ja];
              ptrAna++;
           }
        }
          */ 
        /*
        if (VOLT)               //if sine graph
            NOCHANGE= true;     //no change sample till being read
         * */ 
        switch(CYCLE)
        {
            case 0:     //0->1
                 break;
            case 1:     //0->2
                 OCMP_Clear();
                break;
            case 2:     //1->2
                 break;
            case 3:     //1->0
                 OCMP_Clear();
                break;
            case 4:  //2->0
                 break;
            case 5:     //2->1
                 OCMP_Clear();
                break;
            default:
                break;
        }
        //copy RAM from )adcdma[2] to dad[CYCLE]
        DMAC_ChannelTransfer(DMAC_CHANNEL_1, (const void *)adcdma[2], sizeof(uint16_t[SAMPSTER]), (const void *)dad[CYCLE], sizeof(uint16_t[SAMPSTER]), sizeof(uint16_t[SAMPSTER]));
        DCH1ECONbits.CFORCE = true;//transfer init manually 
        CONTA= false;//t
      }
    }
    //for (ja = 0; ja < (2 * NCANALS); ja++)//reset ADC DMA
    for (ja = 0; ja < NREC; ja++)//reset ADC DMA
        ndma[ja] = 0;
    CYCLE++;
    if(CYCLE==WAVES)
    {
        CYCLE=0;
  //      TBUFUL= false;
        TBUFUL= true;
        LED4_Clear();     //t
    }
    /*
    if (VOLT) //t
    {   //sine graph 
         CONTA=false; //ADC enable    
         if(!NOCHANGE)  //change of samples is not disable
           StartAD();//t
    }
    else    //speed graph
     evaluate(); //in SELFTEST.c
     */
 }

void ADC_DMA_InterruptHandler(void) {
    TMR5_Stop();
    ADCDSTATbits.DMAEN = 0; //t
    ADCDSTATbits.DMACEN = 0; //count enable    
   // ADCHS_ModulesDisable( ADCHS_MODULE0_MASK | ADCHS_MODULE1_MASK| ADCHS_MODULE2_MASK );
    ADCHS_ModulesDisable( ADCHS_MODULE2_MASK );
    auxstat=ADCDSTAT;
    EVIC_SourceStatusClear(INT_SOURCE_ADC_DMA);//ADC interrupt clear
    StopAD();
};

void __ISR(_ADC_DMA_VECTOR, ipl4SOFT) ADC_DMA_Handler (void)
{
    ADC_DMA_InterruptHandler();
}

//ADC is started by transmit clock( half  period after TMR2)
void Y_callback( uintptr_t context)
{
    OSCSTART--;
    if(OSCSTART==0)
        StartAD();//t
}
/*
void Y2_callback( uintptr_t context)
{
    OSCSTART--;
    if(OSCSTART==0)
        StartAD();
}

void Y3_callback( uintptr_t context)
{
    OSCSTART--;
    if(OSCSTART==0)
        StartAD();
}
*/
void TMR2_callback(uint32_t status, uintptr_t context)//40kHz timer for transmitter 
{
    WDTCONbits.WDTCLRKEY=0x5743;
  
    if (!TBUFUL  && !FL_MES) 
    {
       FL_MES= true;
       OSCSTART= OS;
       switch(CYCLE)
       {
           case 0:
//               TRANSMITTER=0;
               OCMP1_Enable ();
               OCMP2_Enable ();
 //              RECEIVER=1;
               MUX_A_Set();
               MUX_B_Clear();
               break;
           case 1:
//               TRANSMITTER=0;
//               RECEIVER=2; 
               MUX_A_Clear();
               MUX_B_Set();                 
               break;
           case 2:
//               TRANSMITTER=1;
               OCMP14_Enable ();
               OCMP9_Enable ();
//               RECEIVER=2;
               break;
           case 3:
 //             TRANSMITTER=1;
//              RECEIVER=0;
               MUX_A_Clear();
               MUX_B_Clear();              
               break;
           case 4:
  //             TRANSMITTER=2;
               OCMP4_Enable ();
               OCMP3_Enable ();
  //             RECEIVER=0;
               break;
           case 5:
//               TRANSMITTER=2;
//               RECEIVER=1;
               MUX_A_Set();
               MUX_B_Clear();
               break;
           default:
               break;    
       }
    }
  //  ADCHS_ChannelConversionStart(ADCHS_CH7); //ntc temp.

}

inline void iniAnals(void) {
    ADCHS_ModulesDisable( ADCHS_MODULE0_MASK | ADCHS_MODULE1_MASK| ADCHS_MODULE2_MASK );//t
   // ADC0TIMEbits.BCHEN = 1; //enable buffer
   // ADC1TIMEbits.BCHEN = 1; //enable buffer
    ADC2TIMEbits.BCHEN = 1; //enable buffer
    ADCCON1bits.DMABL = NR; //buffer bit length
    ADCDSTATbits.RAFIEN2 = 1; //DMA buffer A full interrupt enable
    ADCDSTATbits.RBFIEN2 = 1; //DMA buffer B full interrupt enable
    ADCDSTATbits.RAFIEN1 = 1; //DMA buffer A full interrupt enable
    ADCDSTATbits.RBFIEN1 = 1; //DMA buffer B full interrupt enable
    ADCDSTATbits.RAFIEN0 = 1; //DMA buffer A full interrupt enable
    ADCDSTATbits.RBFIEN0 = 1; //DMA buffer B full interrupt enable
    /*
                              // NTC 
    ADCFLTR4bits.CHNLID = 17; //ADC4 module filter
    ADCFLTR4bits.DATA16EN = 1; // 16bit data
    ADCFLTR4bits.OVRSAM = 3; //256 samples filter
    ADCFLTR4bits.AFEN = 1;
    */
    EVIC_SourceEnable(INT_SOURCE_ADC_DMA); //
    IPC26bits.AD1FCBTIP = 4;    //1; //ADC_DMA interrupt priority  
    IPC26bits.AD1FCBTIS = 2;    //3; //ADC_DMA interrupt subpriority  
    TMR2_CallbackRegister(TMR2_callback, (uintptr_t) NULL);
    OCMP2_CallbackRegister(Y_callback, (uintptr_t) NULL);
    OCMP9_CallbackRegister(Y_callback, (uintptr_t) NULL);
    OCMP3_CallbackRegister(Y_callback, (uintptr_t) NULL);
    MUX_EN_Clear();
    LATDCLR = (1U<<5);
    LATDCLR = (1U<<6);
    LATCCLR = (1U<<0);
    LATCCLR = (1U<<1);
    LATBCLR = (1U<<15);
    LATBCLR = (1U<<14);
    TRISDCLR = (1U<<5);
    TRISDCLR = (1U<<6);
    TRISCCLR = (1U<<0);
    TRISCCLR = (1U<<1);
    TRISBCLR = (1U<<15);
    TRISBCLR = (1U<<14);
    CYCLE=0;   
    TBUFUL= false;
    iniAnafun();
   // ADCHS_ModulesDisable( ADCHS_MODULE0_MASK | ADCHS_MODULE1_MASK| ADCHS_MODULE2_MASK );//t
 }


