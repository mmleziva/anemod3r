
#ifndef _ANAFUN_H    /* Guard against multiple inclusion */
#define _ANAFUN_H
#include "definitions.h"
typedef struct
{
   float ph1;//phases of voltage transition cross zero above, 
   float pha;//phases of voltage transition corrected by LeastSquarts function,      
   float Amp;// amplitude  of the sine signal 
   float dAmp;//offset of the sine signal 
}harm;
//extern int wh,ww,nt;
extern int nt;
//extern int wh,ww;
extern float wh,ww;
//void dFrekv(int16_t df_Hz);
void iniAnafun(void);
bool aver(int16_t *p, harm *ph);
float LeastSquars(int16_t *p, harm *ph);
#endif /* _ANAFUN_H*/
