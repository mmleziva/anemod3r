
#ifndef _ANAFUN_H    /* Guard against multiple inclusion */
#define _ANAFUN_H
#include "definitions.h"
typedef struct
{
   float ph1;//phases of voltage transition cross zero above, 
   float pha;//phases of voltage transition corrected by LeastSquarts function,      
   float Amp;// amplitude  of the sine signal 
   float dAmp;//offset of the sine signal 
}harm;
typedef union 
{
    uint16_t u;
    struct           
    {
      uint16_t CROSSZERO: 1; 
      uint16_t TOOTHS: 1; 
      uint16_t ZERODIV: 1; 
      
    };
}errors;
extern errors err;
//extern int wh,ww,nt;
extern int nt;
//extern int wh,ww;
extern float wh,ww;
//void dFrekv(int16_t df_Hz);
void iniAnafun(void);
uint16_t aver(int16_t *p, harm *ph);
float LeastSquars(int16_t *p, harm *ph);
#endif /* _ANAFUN_H*/
