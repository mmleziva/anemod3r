#include "SELFTEST.h"
#define ADCONST (1650.0/2048.0)//(3300/2)mV/ (0x1000/2)bit 
#define AMPMIN 0x10         //minimal amplitude
uint16_t  bj, bk;
float phs[NRECx2];
harm h[NRECx2];
bool  SELFTE, FAMP[NREC],CORTEST;
bool FIL[NREC];
float dphfil[NREC];
uint16_t ks,ih;
float T;
float TrigPer;//trigger period
float c;
int16_t dad[NRECx2][SAMPS];//[2 * 128];
uint16_t Tset;
float dp,dprep;
extern float dt[NREC];
errors aderr[NRECx2], errsum;//define at anafun.h


//simple dig. Filter(pointer to input value, filtered value, initial zero bit)
void Filter(float *pv, float *pfil, bool *pBEGIN)
{
  bool FAUX; 
  FAUX= (Kfil > 0) && (Kfil < 1);
  
  if( FAUX && *pBEGIN) //continuous filtering 
  {
      *pfil= *pfil+ Kfil  * (*pv-*pfil);
      *pBEGIN= true;
  }
  else if(FAUX)     //start filtering
  {
    *pBEGIN= true;
    *pfil= *pv;
  }
  else      
  {     //unexpected filter constant 
      *pfil= *pv;
  }
  
}

void selftest(void)//setting at zero wind speed, called from evaluate()
{
                                //measurement evaluation
              for(bj=0;bj<NREC;bj++)//
              { 
                  dph0[bj] += dphfil[bj];//t
                   FIL[bj]= false;//t
              }
 }
void resetpar(void)//reseting 
{
                                //measurement evaluation
    for(bj=0;bj<NREC; bj++)//
    {
                      dph0[bj]=0; 
                       FIL[bj]= false;//t
    }
 }
    
extern float AMP0, PH0;
extern float AMP1, PH1;
extern float AMP2, PH2;
inline void evaluate(void)    //processes values of one ultrasound period , called from anals.c: stopAD() 
{
    errsum.u=0;
    for (bj = 0; bj < NRECx2; bj++) //t
    {
                //function anafun.c: aver(adcdma,&h) fill the struct h with the amplitude and phase of the wave "adcdma" 
       aderr[bj].u=aver(dad[bj],&h[bj]); 
       errsum.u |= aderr[bj].u;
       if(! aderr[bj].ZERODIV)
            phs[bj]=LeastSquars(dad[bj],&h[bj]);//separate phases, refined by the method of least squares 
        A[bj]=  h[bj].Amp * ADCONST;
       WDTCONbits.WDTCLRKEY=0x5743;//t
    }
     *perr |= errsum.u;      

     for (bj = 0; bj < NREC; bj++) 
     {
       dp= phs[bj+NREC]- phs[bj];//phase differences
       if (bj==0) {PH0=dp;AMP0=h[bj].Amp;}
       if (bj==1) {PH1=dp;AMP1=h[bj].Amp;}
       if (bj==2) {PH2=dp;AMP2=h[bj].Amp;}         
         
         dprep= dp-dph0[bj];//no wind phase correction
         if (dprep< (-wh))//half-wave reduction
             dprep+=ww;
         else
         if(dprep> (wh))
             dprep-=ww;
         Filter(&dprep,&dphfil[bj],&FIL[bj]);
         dt[bj]=dphfil[bj]*TrigPer;//time difference
         
     }
    *pT=T-273.15; 
  
  }