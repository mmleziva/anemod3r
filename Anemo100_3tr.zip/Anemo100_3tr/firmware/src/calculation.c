
//#pragma region name="ext_mem" origin=0x9d010000 size=0x400
#include "calculation.h"
#define FCLK 6E7   //60MHz clock
#define RUP 10000 //pullup resistor of 10kOhm NTC 
#define R25 10000 //resistance of 10kOhm NTC on 25�C
#define T25 (273.15+25) // temp 25�C in Kelvin  
#define BETA 4300 //ntc thermistor const 
#define MUL_C_SQUARE (20.047*20.047)
#define SQRT3 1.732
float dVx, dVy;
float Vxfil,Vyfil;
float c_square,Vx,Vy,Vabs, Fi,R,dtx,dty,  phfil[NREC],dV[NREC],dt[NREC];
uint16_t k,jj,ik, jw,kw;
uint16_t Ntr,STAN;
float uadc;
float *ptrW;   
volatile float W[NPACK][NREC];// __attribute__ (( address(0xa0001100))); //t;     


float Rntc(float Uad)// calculate NTC resistance from ADC value of voltage divider;
{
 return RUP*(Uad/(0x01000-Uad));
}

float Tntc(float Rt)//calculate temperature from resistance of NTC thermistor
{ float invT;
 invT= log(Rt/R25)/BETA;
 return (1/(invT + 1/T25));
}

inline void inicalc(void)
{
    uadc=0x00800;
    flashread();
    TrigPer= (TRIGPER/ FCLK)*1000;//1000mm=1m       
    if(Kfil <= 0)Kfil=1;
    c=344;//t
 //   ph0= (Lx)/(c*TrigPer); //standard absolute phase   
    STAN=STARTPAUSE;
    TEMPBLOCK= true;//t
    conf_interf();
}


inline void calc(void)//velocity computing, called each 10ms  from scheduler.c
{

 if(ADCFLTR4bits.AFRDY)       //ntc ADC
 {
    ADCFLTR4bits.AFRDY= false;
    uadc=((float)ADCFLTR4bits.FLTRDATA)/16;   //average ntc voltage from inner filter
 }   
    
 if((uadc>0) && (uadc< 0x1000))//adc scope
 {
     if(TEMPBLOCK)
       T= 273.15+20;
     else
     {
      R= Rntc(uadc);// calculate NTC resistance from ADC value of voltage divider;
      T=Tntc(R);//calculate temperature from resistance of NTC thermistor
     }
    c_square= MUL_C_SQUARE * T; //c^2= const*T
    c=331.82+ 0.61*(T-273.15);//calculate sound speed from temperature
 }
 else
 {     
    c=340;
 //   c_square = (c * c);
 }
  for(k=0; k< NREC; k++)  
 {
     dV[k]= - dt[k]*c_square/(2*Lx); 
      W[jj][k]= dV[k];  //a series of values
 } 
 Vy= (dV[1]- dV[2])/SQRT3;
 Vx= dV[0];
 Vabs = sqrtf(Vx*Vx + Vy*Vy);//absolute wind speed
 Fi= atan2(Vx,Vy)*(180/M_PI);   // azimuth of wind
 jj++;
 if(jj >= NPACK)
 {
   jj=0;
   LED1_Toggle();//test
   if (!VOLT) //speed measurement mode
   {                                               //transfer to modbus inputs
      ptrW=(float *) &(INPREGS[ADRVEL].W);
      DMAC_ChannelTransfer(DMAC_CHANNEL_2, (const void *)W, sizeof(float[NPACK*NREC]), (const void *)ptrW, sizeof(float[NPACK*NREC]), sizeof(float[NPACK*NREC]));
          }
   }   
 if(NEUTRAL)//transfers self-test command
 { 
      NEUTRAL= false;  
      selftest();
    //  *pLx= Lx;   //modbus params
    //  *pKfil= Kfil;
      flashwrite();
   }
   else if(DENULL)//reset parameters - annull corrections
   {  DENULL= false;        
      resetpar();
      //Lx= LDIST;// reset of inverse proportionality constant 
      //Kfil=1;       //reset filter constant
      flashwrite();
   }    
  } 
   /*
   if(jj >= 100)
   {
     jj=0;
     Ntr=sprintf(ser,"Vx=%7.3f ; Vy=%7.3f ; Vabs=%7.3f ; Fi= %7.3f",(double)Vx,(double)Vy,(double)Vabs,(double)Fi); //Harmony pherip.func.
     DMAC_ChannelTransfer(DMAC_CHANNEL_7, (const void *)ser, Ntr+1 , (const void *)&U6TXREG, 1, 1); //Harmony pherif.func.        
     DCH7ECONbits.CFORCE = true;//transfer init manually 
   } 
    */ 
// }
// StartAD();//t

/*
inline void except(void)
{
    if(_excep_code == EXCEP_Overflow)
        LED2_Set();
    else
    if(_excep_code == EXCEP_IRQ)
         LED1_Set();
    else
    if((_excep_code == EXCEP_AdES)||(_excep_code ==EXCEP_AdEL)||(_excep_code == EXCEP_IBE)||(_excep_code ==EXCEP_DBE))
         LED3_Set();
    else
        LED4_Set();
}
 */ 
