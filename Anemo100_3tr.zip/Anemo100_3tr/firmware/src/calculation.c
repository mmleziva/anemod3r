
#include "calculation.h"
#define FCLK 6E7   //60MHz clock
#define RUP 10000 //pullup resistor of 10kOhm NTC 
#define R25 10000 //resistance of 10kOhm NTC on 25�C
#define T25 (273.15+25) // temp 25�C in Kelvin  
#define BETA 4300 //ntc thermistor const 
#define MUL_C_SQUARE (20.047*20.047)
#define SQRT3 1.732
//int16_t VabsInt16;//t
//int16_t FiInt16;//t
float c_square,Vx,Vy,Vabs, Fi,R,dtx,dty,dV[NREC],dt[NREC],Vn;
uint16_t k,jj,ik, jw,kw;
uint16_t Ntr,STAN;
float uadc;
float *ptrW;   
volatile float W[NPACK][NREC];


float Rntc(float Uad)// calculate NTC resistance from ADC value of voltage divider;
{
 return RUP*(Uad/(0x01000-Uad));
}

float Tntc(float Rt)//calculate temperature from resistance of NTC thermistor
{ float invT;
 invT= log(Rt/R25)/BETA;
 return (1/(invT + 1/T25));
}

inline void inicalc(void)
{
    uadc=0x00800;
    flashread();
    TrigPer= (TRIGPER/ FCLK)*1000;//1000mm=1m       
    if(Kfil <= 0)Kfil=1;
//    c=344;//t
//     TEMPBLOCK= true;//t
    conf_interf();
}

extern float SPEED,DIR;
inline void calc(void)//velocity computing, called each 10ms  from scheduler.c
{
/*
 if(ADCFLTR4bits.AFRDY)       //ntc ADC
 {
    ADCFLTR4bits.AFRDY= false;
    uadc=((float)ADCFLTR4bits.FLTRDATA)/16;   //average ntc voltage from inner filter
 }   
    
 if((uadc>0) && (uadc< 0x1000))//adc scope
 {
     if(TEMPBLOCK)
       T= 273.15+20;
     else
     {
      R= Rntc(uadc);// calculate NTC resistance from ADC value of voltage divider;
      T=Tntc(R);//calculate temperature from resistance of NTC thermistor
     }
    c_square= MUL_C_SQUARE * T; //c^2= const*T
    c=331.82+ 0.61*(T-273.15);//calculate sound speed from temperature
 }
 else
 {     
    c=340;
 }
 * */
  T= 273.15+20;
   //   c_square = (c * c);
  c_square= MUL_C_SQUARE * T; //c^2= const*T
  for(k=0; k< NREC; k++)  
  {
     dV[k]= - dt[k]*c_square/(2*Lx); 
#ifdef MODBUS       //def. in mb_interf.h 
      W[jj][k]= dV[k];  //a series of values
#endif
  } 
  Vy= (dV[2]- dV[0])/SQRT3;
  Vx= dV[1];
  Vn= dV[0]-dV[1]+dV[2]; //control sum may be zero
  Vabs = sqrtf(Vx*Vx + Vy*Vy);//absolute wind speed
  //VabsInt16= (int16_t)(Vabs*100);//t
  Fi= atan2(Vx,Vy)*(180/M_PI) + 180;   // azimuth of wind
  //FiInt16= (int16_t)(Fi*100);//t
  
   SPEED=Vabs;
   DIR=Fi;
  
  jj++;
  if(jj >= NPACK)
  {
   jj=0;
#ifdef MODBUS       //def. in mb_interf.h                                           //transfer to modbus inputs
   if (!VOLT) //speed measurement mode
   {   
      ptrW=(float *) &(INPREGS[ADRVEL].W);
      DMAC_ChannelTransfer(DMAC_CHANNEL_2, (const void *)W, sizeof(float[NPACK*NREC]), (const void *)ptrW, sizeof(float[NPACK*NREC]), sizeof(float[NPACK*NREC]));
   }
#endif
  }   
  if(NEUTRAL)//transfers self-test command
  { 
      NEUTRAL= false;  
      selftest();
      flashwrite();
  }
  else if(DENULL)//reset parameters - annull corrections
  {  DENULL= false;        
      resetpar();
      flashwrite();
  }    
} 
   /*
   if(jj >= 100)
   {
     jj=0;
     Ntr=sprintf(ser,"Vx=%7.3f ; Vy=%7.3f ; Vabs=%7.3f ; Fi= %7.3f",(double)Vx,(double)Vy,(double)Vabs,(double)Fi); //Harmony pherip.func.
     DMAC_ChannelTransfer(DMAC_CHANNEL_7, (const void *)ser, Ntr+1 , (const void *)&U6TXREG, 1, 1); //Harmony pherif.func.        
     DCH7ECONbits.CFORCE = true;//transfer init manually 
   } 
    */ 
// }
// StartAD();//t

/*
inline void except(void)
{
    if(_excep_code == EXCEP_Overflow)
        LED2_Set();
    else
    if(_excep_code == EXCEP_IRQ)
         LED1_Set();
    else
    if((_excep_code == EXCEP_AdES)||(_excep_code ==EXCEP_AdEL)||(_excep_code == EXCEP_IBE)||(_excep_code ==EXCEP_DBE))
         LED3_Set();
    else
        LED4_Set();
}
 */ 
