/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "anals.h" 
#include "debug.h" 
// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
float AMP0, PH0;
float AMP1, PH1;
float AMP2, PH2;
float SPEED, DIR;
int main ( void )
{
    /* Initialize all modules */
    ADMApreset();
    SYS_Initialize ( NULL );
    debug_init(1);
    debug_print_str("\r\nSTARTIIINNNG1111111111111111111111");
    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
        delay_ms(100);
        debug_print_str("\rAMP0:");
        debug_print_float(AMP0,0);
        debug_print_str("\tAMP1:");
        debug_print_float(AMP1,0);
        debug_print_str("\tAMP2:");
        debug_print_float(AMP2,0);
        debug_print_str(" \tPH0:");
        debug_print_float(PH0,1);
        debug_print_str(" \tPH1:");
        debug_print_float(PH1,1);
        debug_print_str(" \tPH2:");
        debug_print_float(PH2,1);
        debug_print_str(" \tSPEED:");
        debug_print_float(SPEED,2);
        debug_print_str(" \tDIR:");
        debug_print_float(DIR,2);        
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

