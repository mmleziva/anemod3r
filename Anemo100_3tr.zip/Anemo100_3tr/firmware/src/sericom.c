#include "sericom.h"
char sync;
char rxData,rstring[SMAX+1];
short int irx,nstr;
UARTFLAGS uarf1;
bool FURT;
unsigned char bufout[BUFOUTMAX+1],bufin[BUFINMAX+1];
unsigned char  *pbufo;
void UART_WriteHandler(uintptr_t context);
void UART_ReadHandler(uintptr_t context);

//main DMA
void APP_DMA_TransferEventHandler(DMAC_TRANSFER_EVENT event, uintptr_t contextHandle)
{
    uarf1.WRITBUSY= false;
    switch(event)
    {
        case DMAC_TRANSFER_EVENT_COMPLETE:
            // This means the data was transferred.            
            // LED4_Clear();
              break;

        case DMAC_TRANSFER_EVENT_ERROR:
            // Error handling here.
           //LED4_Clear();
             break;

        default:
            break;
    }
}

bool serini()
{
    bool tst= false;
 DMAC_Initialize();//t
 pbufo=&bufout[0];
 //uart harmony interrupt handlers   
 DMAC_ChannelCallbackRegister(DMAC_CHANNEL_0, APP_DMA_TransferEventHandler,(uintptr_t)NULL);
 UART6_ReadCallbackRegister( UART_ReadHandler, (uintptr_t)NULL) ;//Harmony pheriph.func.
 if(!UART6_ReadIsBusy())//Harmony pheriph.func.   
 {
   tst= UART6_Read(&rxData, sizeof(uint8_t ));//Harmony pheriph.func.   
 }
  U6STAbits.UTXISEL=2;//t
  uarf1.Fred= true;//t
  return tst;
}
/*
void Autos(void)
{
  Npaus++;
  if(Npaus > NP)
  {
   Npaus=0;
   uarf1.Fred= 0;  
  U1MODEbits.ABAUD = 1;	//t
  }
}

 */ 

void UART_ReadHandler(uintptr_t context)
{  
   // UART6_ErrorGet();
    if(!uarf1.Fred)
    {
     {   
     // U1TXREG= sync=0xaa;//t
     }
 }
 else
 {
  if(T4CONbits.ON == false)
  {
   uarf1.ErrPar=0;
   TMR4_Start ();
   irx=0;
  }
  TMR4 = 0;		
  if(U6STAbits.OERR)U6STAbits.OERR=0;		// Enable UART Tx 
  if(irx < BUFMAX)
  {
   rstring[irx]= rxData;    
   irx++;//number of chars received 
  }
 } 
  UART6_Read(&rxData, sizeof(uint8_t )); //wait for data to be received
}


void startU1tr(int n)//start transmit of this card data to UART6->USB 
{
 if(!uarf1.WRITBUSY && (n>=6)&&(n<=BUFOUTMAX))
 {
     uarf1.WRITBUSY= true;
    IFS5bits.U6TXIF= false;
    FURT= DMAC_ChannelTransfer(DMAC_CHANNEL_0, (const void *)bufout, n  , (const void *)&U6TXREG, 1, 1); //Harmony pherif.func.        
     //LED4_Set();
    DCH0ECONbits.CFORCE = true;//transfer init manually
    WDTCONbits.WDTCLRKEY=0x5743;
 }
} 