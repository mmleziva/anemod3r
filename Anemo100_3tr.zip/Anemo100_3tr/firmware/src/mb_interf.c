            //modbus and flash interface
#include "mb_interf.h"
bool TEMPBLOCK;
bool VOLT,NEUTRAL,DENULL;
float * const pLx= (float *)&HOLDREGSR[2];    //pointer to float 
float * const pKfil=(float *)&HOLDREGSR[4];    //pointer to float 
float *const phred= (float *)&HOLDREGSR[6];    //pointer to float 
float *const pT=  (float *)&INPREGS[2];
float *const A=   (float *)&INPREGS[6];
uint8_t COMMAND, *ptrCOMMAND, inc; 
float Kfil;
float Lx;
float dph0[NREC];
bool RESX, RESY;
uint16_t mj,nana,ADRHDOC;
int16_t df_Hz_mb;
bool NOCHANGE,ANAC,CONTA;
const float  __attribute__((aligned(0x4000))) AddrNVM[0x10]= {0,0,0,0,0,0,0,0,LDIST,1};//t   
//extern float ww,wh;

void flashread(void)
{
    RESY= NVM_Read( (uint32_t *)dph0, (sizeof(float[NREC])), (uint32_t)AddrNVM );
    RESY= NVM_Read( (uint32_t *) (&Lx),sizeof(float), (uint32_t)(AddrNVM+8) );
    RESY= NVM_Read(  (uint32_t *) (&Kfil), sizeof(float), (uint32_t)(AddrNVM+9));
}

void flashwrite(void)
{
    RESX= NVM_PageErase( (uint32_t)AddrNVM);//t
    while(NVM_IsBusy());
    RESX= false;
    RESX=NVM_QuadWordWrite((uint32_t*)dph0, (uint32_t)AddrNVM);
    while(NVM_IsBusy());
    RESX= false;
    RESX= NVM_WordWrite( *(uint32_t *)(&Lx), (uint32_t)(AddrNVM+8));
    while(NVM_IsBusy());
    RESX= false;
    RESX= NVM_WordWrite(*(uint32_t *)(&Kfil),(uint32_t)(AddrNVM+9));
    while(NVM_IsBusy());
 }

void conf_interf(void)
{
      ptrCOMMAND=&(HOLDREGSR[0].L);
      *pLx= Lx;
      *pKfil= Kfil;
      for(mj=0; mj<NREC;mj++)
     {
             phred[mj]= dph0[mj];
     }
     
     cfgModbus();
     
}

void mwend(void)
{
   if(mbs.funCode == 0x4)
   {     
      if(mbs.startAdr.W == (ADR0INPREG+SAMPSTER+ADRANA))//t
      {
       }
      else
      if(mbs.startAdr.W == (ADR0INPREG + ((NREC-1)*SAMPSTER + ADRANA)))
      {
  //        NOCHANGE= false;
       }
      else
          if(mbs.startAdr.W == (ADR0INPREG+ADRANA))//t
      {
        //       TBUFUL= false;
       }
   }
}


void interf (void)
{     
 if(mbs.received)
 {
  mbs.received= false;
 // LED4_Set();//t
  switch(mbs.funCode)
  {   
    
    case 0x3:
     {
        mj++;//t
         for(mj=0; mj<NREC;mj++)
           {
              phred[mj]= dph0[mj];
           }
     }
     break; 
/* 
     case 0x4:
     {
      if(mbs.startAdr.W == (ADR0INPREG))
      {
          
      }
      else if(mbs.startAdr.W == (ADR0INPREG+ADRANA))
      {
      }
      else if(mbs.startAdr.W == (ADR0INPREG+SAMPSTER+ADRANA))//t
      {
          NOCHANGE= true;//t
      }    
     }
     break;
 */ 
    case 0x10:
    {
     ADRHDOC=  ADR0HOLDREG+ AHDOC;
     if(mbs.startAdr.W== ADRHDOC)
     {      
          df_Hz_mb= HOLDREGSR[AHDOC].W;
          dFrekv(df_Hz_mb);         //anafun.c    
     }
     else if(mbs.startAdr.W != ADR0HOLDREG)
     {
      Lx= *pLx;
      Kfil= *pKfil;
      flashwrite();
     }
     else
     {
      COMMAND= *ptrCOMMAND;
      switch(COMMAND)
      {
        case 'b':
             TEMPBLOCK= true;//block temp meas.
        break;
        case 'a':
             TEMPBLOCK= false;//enable temp. meas.
        break;
        case 'u':
             VOLT= true; 
        break;
        case 'v':
             VOLT= false;
  //           NOCHANGE= false;//t   
        break;
        case 'n':
             NEUTRAL= true;//receives self-test command
        break;
        case 'd':
             DENULL= true;//receives reset parameters command
        break;
        case 's': 
            break;  
        case 'x':
            nana=0;
        break;
        case 'y':
            nana=1;
        break;
        case 'z':
            nana=2;
        break;
        default:
        break;
      }
      COMMAND=0;    
    }
   }
  }
 }
}