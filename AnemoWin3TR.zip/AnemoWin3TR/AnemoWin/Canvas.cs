﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnemoWin
{
    public partial class MainWindow : Window
    {
        public void CreatePolyline()
        {
            GreenPoints.Clear();
            BlackPoints.Clear();
            BluePoints.Clear();
            RedPoints.Clear();
            //platno.Children.Clear();
            platno.Children.Remove(greenPolyline);
            platno.Children.Remove(blackPolyline);
            platno.Children.Remove(bluePolyline);
            platno.Children.Remove(redPolyline);
            for (int i = 0; i < SAMPS; i++)
            {
                P[i, 0].X = P[i, 1].X = P[i, 2].X = P[i, 3].X = i * 10;
                P[i, 0].Y = A[i, 0] / 10;
                P[i, 1].Y = A[i, 1] / 10;
                P[i, 2].Y = A[i, 2] / 10;
                P[i, 3].Y = A[i, 3] / 10;
                BlackPoints.Add(P[i, 0]);
                RedPoints.Add(P[i, 1]);
                BluePoints.Add(P[i, 2]);
                GreenPoints.Add(P[i, 3]);
            }
            greenPolyline.Points = GreenPoints;
            blackPolyline.Points = BlackPoints;
            redPolyline.Points = RedPoints;
            bluePolyline.Points = BluePoints;
            platno.Children.Add(greenPolyline);
            platno.Children.Add(blackPolyline);
            platno.Children.Add(bluePolyline);
            platno.Children.Add(redPolyline);

        }




    }
}
