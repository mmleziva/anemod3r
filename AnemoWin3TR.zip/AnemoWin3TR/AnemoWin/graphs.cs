﻿using System;
using System.IO.Ports;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Threading;
using System.Windows.Controls;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;
using MB;



namespace AnemoWin
{    // public class Graph 
    public partial class MainWindow : Window
    {
        //public ProgressBar memo;
        public static float AV;
        public double fa0, fa1;
        public static double fimi,Velx,Vely;
        public static int brr, testb;
        public static TimeSpan longtime, shortime;
        public PlotModel MyModel { get; private set; }//OxyPlot function
        public static bool VACT=false, VOLT=true, ADT= true,INISCAN= true;
        public const int SAMPS = 20;
        public const int SAMPANA =64;//ADC samples
        public const int CH = 3;
        public const int CHOSC = 2;
        public static bool[] axes = new bool[CH];
        public static byte[]rgb  = new byte[CH];
        public const int SAMPA = 120;//=SAMPANA*CH
        public static int HR = 650;
        public static int NR;
        public static Int16[,] A;
        public static Single[,] F;
        public OxyPlot.Series.LineSeries[] s = new OxyPlot.Series.LineSeries[CH];//OxyPlot function
        public OxyPlot.Series.LineSeries[] sa = new OxyPlot.Series.LineSeries[CH];//OxyPlot function
        public OxyPlot.Series.LineSeries sf = new OxyPlot.Series.LineSeries();//OxyPlot function
        public OxyPlot.Series.LineSeries sg = new OxyPlot.Series.LineSeries();//OxyPlot function
        public static float MAXVEL = 50;
        public const double ABSMAXVEL = 100;
        public const double MAXANA = 2048;
        public const double KATIM = 0.25; //0.3185;
        public const double QARTER = 6.25;//(SAMPS * KATIM); 
        public static int i, j, k;
        public static bool STOP = false, SELFT = false, CLICK = false, GX = false, GY = false, GU = false, GWM=false,WAIT=false;
        public static bool SETPLOT = false;//t
        public static DispatcherTimer ScanTimer;
        string x, y;
        //public double sum0, sum1;
      //  public double[] sum = new double[CH];;
        public static int MAXS = 26000;
        public delegate void req(byte unitId, byte funCode, ushort startAdr, ushort quantity);
        public event req MBreq ;
        public static uint nreq, nresp, nana;
        public static Int16 errorsrec;  //t
//        public string uCerrStr;
        public void Graph()
        {
            NR = HR / SAMPS;
            A = new Int16[SAMPA, CHOSC];
            F = new Single[SAMPS, CH];
            x = SAMPA.ToString("-000000");
            y = KATIM.ToString("-0.0000");
            MyModel = new PlotModel
            {//OxyPlot function
                Title = "Wind speed- components",
            };
            MyModel.Axes.Clear();
            MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Bottom, Minimum = 0, Maximum = SAMPA * KATIM, AbsoluteMinimum = 0, AbsoluteMaximum = SAMPA * KATIM }); ;
            MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Left, Minimum = -MAXANA, Maximum = MAXANA, AbsoluteMinimum = -MAXANA, AbsoluteMaximum = MAXANA });
 
            MyModel.Series.Clear();
            MyModel.Axes[0].Minimum = 0;//t
            MyModel.Axes[0].Maximum = HR / 100;
            MyModel.Axes[1].Minimum = -MAXVEL;
            MyModel.Axes[1].Maximum = MAXVEL;
            MyModel.Axes[0].AbsoluteMinimum = 0;//t
            MyModel.Axes[0].AbsoluteMaximum = HR / 100;
            MyModel.Axes[1].AbsoluteMinimum = -ABSMAXVEL;
            MyModel.Axes[1].AbsoluteMaximum = ABSMAXVEL;

            for (i = 0; i < CH; i++)
            {
                s[i] = new OxyPlot.Series.LineSeries();//OxyPlot function...
                for (int ix = 0; ix < 3; ix++)
                {
                    if (ix == i) rgb[ix] = 0xff;
                    else rgb[ix] = 0;
                }
                s[i].Color = OxyColor.FromRgb(rgb[0], rgb[1], rgb[2]);
                s[i].Title = "V" + i.ToString(); 
                s[i].StrokeThickness = 1.5;
                 MyModel.Series.Add(s[i]);
            }
           
            sf.Points.Add(new DataPoint(0, MAXVEL));
            sf.Points.Add(new DataPoint(0, -MAXVEL));
            sf.Points.Add(new DataPoint(0, 0));
            sf.Points.Add(new DataPoint(HR, 0));
            sf.StrokeThickness = 1;
            this.MyModel.Series.Add(sf);
            
         
            for (i = 0; i < CH; i++)
            {
                sa[i] = new OxyPlot.Series.LineSeries();//OxyPlot function...
                for (int ix = 0; ix < 3; ix++)
                {
                    if (ix == i) rgb[ix] = 0xff;
                    else rgb[ix] = 0;
                }
                sa[i].Color = OxyColor.FromRgb(rgb[0], rgb[1], rgb[2]);
                sa[i].Title = "Axe" + i.ToString();
                sa[i].StrokeThickness = 1.5;
                MyModel.Series.Add(sa[i]);
            }
            sg = new OxyPlot.Series.LineSeries();//OxyPlot function...               
            sg.StrokeThickness = 1.5;
            MyModel.Series.Add(sg);
            sg.StrokeThickness = 1;//...OxyPlot function
            ScanTimer = new DispatcherTimer();
            ScanTimer.Tick += new EventHandler(ScanTimer_Tick);
            ScanTimer.Interval = new TimeSpan(0, 0, 0, 0, 200);//  200ms interval
            ScanTimer.Start();
         }
       

        public static  double Abs(double x, double y)
        {
            return Math.Sqrt(x * x + y * y);
        }

        public void ScanTimer_Tick(object sender, EventArgs et)
        {
            try
            {
                if (B.CRCERR || !ser.serial.IsOpen || WAIT)
                    errorsrec++;
                else errorsrec = 0;
                if (errorsrec > 10)
                {
                    errorsrec = 0;
                    
                    ser.OpenCOM();
                    if (ser.serial.IsOpen)
                        COM.Background = Brushes.LightGreen;
                    else
                        COM.Background = Brushes.Pink;
                    COM.Content = MB.ser.serial.PortName;
                    WAIT = false;//t
                   
                }
                axes[0] = (bool)a.IsChecked;
                axes[1] = (bool)b.IsChecked;
                axes[2] = (bool)c.IsChecked;
                if (!SETPLOT)
                {
                    SETPLOT = true;
               }
                modecontrol();
                if (COMMAND)
                { }
                else if (VACT)
                {
                    Modbus.ReqStruc.unitId = 0x1;
                    Modbus.ReqStruc.funCode = 0x4;
                    Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.INPADR0 + ADRANA);
                    Modbus.ReqStruc.quantity.w = (ushort)(2*(SAMPANA-1));

                }
                else
                if(INISCAN)
                {
                    INISCAN = false;
                    Modbus.ReqStruc.unitId = 0x1;
                    Modbus.ReqStruc.funCode = 0x3;
                    Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.HOLDADR0 + 2);
                    Modbus.ReqStruc.quantity.w = 20;
                 }
                else
                if(ADT)
                {
                    ADT = false;
                    Modbus.ReqStruc.unitId = 0x1;
                    Modbus.ReqStruc.funCode = 0x4;
                    Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.INPADR0);
                    Modbus.ReqStruc.quantity.w =  14;
                }
                else
                {
                    Modbus.ReqStruc.unitId = 0x1;
                    Modbus.ReqStruc.funCode = 0x4;
                    Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.INPADR0 + ADRANA + CH * SAMPA);
                    Modbus.ReqStruc.quantity.w = 2*SAMPS*CH;
                }
                if (!WAIT)
                {
                    WAIT = true;
                    Modbus.Require(Modbus.ReqStruc);
                    // Errors.Text = "uC_err: 0x"+ uCerr.ToString("X")+"\n"+ nreq.ToString() + " " + nresp.ToString() + " " + nana.ToString()+"\n"+errstr;
                    Errors.Text = "uC_err: " + uCerrStr + "\n" + nreq.ToString() + " " + nresp.ToString() + " " + nana.ToString() + "\n" + errstr;
                    nreq++;
                }

            }
            catch (Exception e)
            {
                System.Windows.MessageBox.Show("Timer tick except:\n" + e.ToString());

            }
        }

        public void modecontrol()
        {
            if ( VACT && !VOLT)
            {
                VOLT = VACT;
                nreq = nresp = nana = 0;
                MyModel.Title = "Amplified Receiver voltages[ADC bits]";
                MyModel.Axes.Clear();
                MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Bottom, Minimum = 0, Maximum = SAMPANA * KATIM, AbsoluteMinimum = 0, AbsoluteMaximum = SAMPA * KATIM }); ;
                MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Left, Minimum = -MAXANA, Maximum = MAXANA, AbsoluteMinimum = -MAXANA, AbsoluteMaximum = MAXANA });
                MyModel.Series.Clear();
                this.MyModel.Series.Add(sg);
                for (i = 0; i < CHOSC; i++)
                    this.MyModel.Series.Add(sa[i]);             
             }
            else if (!VACT && VOLT)
            {
                nreq = nresp = nana = 0;
                VOLT = VACT;
                MyModel.Title = "Wind speed-components";
                MyModel.Axes.Remove(MyModel.Axes[1]);
                MyModel.Axes.Remove(MyModel.Axes[0]);
                MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Bottom, Minimum = 0, Maximum = (double)HR / 100, AbsoluteMinimum = 0, AbsoluteMaximum = (double)HR / 100 });
                MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Left, Minimum = -MAXVEL, Maximum = MAXVEL, AbsoluteMinimum = -ABSMAXVEL, AbsoluteMaximum = ABSMAXVEL });
                MyModel.Series.Clear();
                this.MyModel.Series.Add(sf);                
                for (i = 0; i < CH; i++)
                    this.MyModel.Series.Add(s[i]);

            }
        }


        public void CreatePolyline()
        {
            double con;
           
            k = ADRANA ;
            for (int j = 0; j < CHOSC; j++)
            {
                for (int i = 0; i < SAMPANA; i++)
                {
                    A[i, j] = (short)Modbus.INPREGS[k].w;
                    k++;
                }
            }

             {
                if (GU)
                    con = KATIM * 6;
                else
                    con = KATIM;
                nana++;
                for (int ij = 0; ij < CHOSC; ij++)
                    sa[ij].Points.Clear();                
                for (int i = 0; i < SAMPANA; i++)
                {
                   for (int ij = 0; ij < CHOSC; ij++)
                  //  if (axes[ij])
                         sa[ij].Points.Add(new DataPoint(i * con, A[i, ij]));
                }
                sg.Points.Add(new DataPoint(0, 0));//t
                sg.Points.Add(new DataPoint(SAMPANA * KATIM, 0));//t
                this.MyModel.InvalidatePlot(true);
            }
        }
  
         public void CreatePolySpeed()
        {
             if (j >= HR)
            {
                j = 0;
                for (i = 0; i <  (CH);i++)
                {
                    s[i].Points.Clear();
                }
            }
            k = 0;
            for (int i = 0; i <  SAMPS; i++)
            {                
                  {
                     {
                        for (int ijk = 0; ijk < CH; ijk++)
                        {
                            F[i, ijk] = Modbus.ConvRegsToFloat(Modbus.INPREGS, ADRANA + CH * SAMPA + 2 * (CH * i + ijk));
                            if (axes[ijk])
                                s[ijk].Points.Add(new DataPoint(0.01 * j, F[i, ijk]));
                            sum[ijk] += F[i,ijk];
                        }
                    }
                  }
                j++;
                if (j >= HR)
                {
                    ADT = true;
                }
            }
            vals();
            this.MyModel.InvalidatePlot(true);
        }       

    }


}