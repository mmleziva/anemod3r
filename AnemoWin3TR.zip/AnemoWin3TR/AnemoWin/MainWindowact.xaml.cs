﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO.Ports;
using System.Windows.Threading;


namespace AnemoWin
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
 
    public class ser
    {
        public static bool BOPEN = false,WH=false;
        public static int n,k,m;
        public static string[] ports;
        public static List<string> portsList;
        public static SerialPort serial;
        public static DispatcherTimer Timer;
        public delegate void err(string er, Exception e);
        public static UInt16[,] A = new UInt16[50,4];
        public static byte [] wb= new byte[2];
        public static bool SYNC = false;//t
        public static event err Err;
        public Point[] P = new Point[50];
        public Polyline yellowPolyline;

        public ser()
        {
            serial = new SerialPort();

            serial.DataReceived += new SerialDataReceivedEventHandler(Read);
            ports = SerialPort.GetPortNames();
            portsList = new List<string>();
            foreach (string s in ports)
            {
                portsList.Add(s);
            }            
            n = portsList.Count - 1;
             serial.PortName = portsList[n];
             serial.BaudRate = 115200;
             OpenCOM();
            portsList.Add("NONE");
            Initim();
            // Create a blue and a black Brush  
            SolidColorBrush yellowBrush = new SolidColorBrush();
            yellowBrush.Color = Colors.Yellow;
            SolidColorBrush blackBrush = new SolidColorBrush();
            blackBrush.Color = Colors.Black;
            // Create a polyline  
            yellowPolyline = new Polyline();
            yellowPolyline.Stroke = blackBrush;
            yellowPolyline.StrokeThickness = 2;

        }



        //configure timer
        public void Initim()
        {
            Timer = new DispatcherTimer();
            Timer.Interval = new TimeSpan(0, 0, 0, 0, 200);//200ms interval
            Timer.Tick += new EventHandler(Timer_Tick);
        }
        public void Timer_Tick(object sender, EventArgs et)
        {
            try
            {
              
                Timer.Stop();
                SYNC = false;
                CreatePolyline();
                for (n = 0; n < 50; n++)
                {
                    Console.Write(A[n, 0].ToString("N0000")+" ");
                    Console.Write(A[n,1].ToString("N0000") + " ");
                    Console.Write(A[n,2].ToString("N0000") + " ");
                    Console.WriteLine(A[n, 3].ToString("N0000"));
                }
                Console.WriteLine();
            }
            catch (Exception e)
            {
                System.Windows.MessageBox.Show("Timer tick except:\n" + e.ToString());

            }
        }

        public void CreatePolyline()
        {
            PointCollection polygonPoints = new PointCollection();
            for (int i = 0; i < 50; i++)
            {

                P[i].X = i * 10;
                P[i].Y = ser.A[i, 1]/10;
                polygonPoints.Add(P[i]);
            }
            yellowPolyline.Points = polygonPoints;
            // Add polyline to the page  
         //   MainWindow.polyf(yellowPolyline);
            
        }

        //opening COM port
        public static void OpenCOM()
        {
            if (!serial.IsOpen)
            {
                serial.Open();
            }
        }

        public static List<string> Getportnames()
        {
            //   ports = SerialPort.GetPortNames();
            portsList = new List<string>();
            foreach (string s in ports)
            {
                portsList.Add(s);
            }
            portsList.Add("NONE");
            return portsList;
        }


        //delegate of COM data receive
        private static void Read(object sender, SerialDataReceivedEventArgs ex)
        {
            byte R;
            try
            {
                if (serial.IsOpen)
                {
                    while (serial.BytesToRead > 0)
                    {
                        R= (Byte)serial.ReadByte();
                        if (!SYNC)
                        {
                            SYNC = true;
                            k = 0;
                            m = 0;
                            WH = false;
                            Timer.Start();
                        }
                        if (WH)
                        {
                            wb[1] = R;
                            if (k < 50) A[k, m] = BitConverter.ToUInt16(wb, 0);
                            m++;
                        }
                        else
                        {
                            wb[0] = R;
                        }
                        WH = !WH;
                        if (m >= 4)
                        {
                                m = 0;
                                k++;
                        }                    
                    }               
                }
            }
            catch (Exception e)
            {
                //  System.Windows.MessageBox.Show("Reading from serial line except:\n"+ e.ToString());
                Err("Reading from serial line except:\n", e);
            }
        }

        //write buffer to COM port
        public static void Write(byte[] buf, int len)
        {
            try
            {
                if ((BOPEN) && (serial.IsOpen == true))
                {

                    serial.Write(buf, 0, len);
                }
            }
            catch (Exception e)
            {
                //System.Windows.MessageBox.Show("Writting to COM port except:\n"+e.ToString());
                Err("Writting to COM port except:\n", e);
            }
        }

    }

    public partial class MainWindow : Window
    {
        static int[] bauds = { 9600, 19200, 38400, 76800, 115200 };
    
        public MainWindow()
        {
            InitializeComponent();
            iniSerial();
           
        }

        private void iniSerial()
        {
            ser ser = new ser();
          
            comboBox.ItemsSource = ser.portsList;
            comboBox.SelectedIndex = ser.n;
            if (ser.serial.IsOpen)
            { 
                comboBox.Background = Brushes.Green;
                comboBox.Foreground = Brushes.DarkGreen;
            }


            ser.BOPEN = true;
        }
        private void comboBox_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            /*   
               try
               {
                   comboBox.SelectedIndex = 0;

                   {
                       comboBox.Items.Add(comport);
                   }
               }
               catch (Exception ex)
               {
                   System.Windows.MessageBox.Show(ex.ToString());
               }
               */
        }
        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            try
            {
                if (ser.BOPEN && (comboBox.SelectionBoxItem != comboBox.SelectedItem))
                {

                    // ser.Getportnames();
                    //   comboBox.ItemsSource = ser.ports;
                    // comboBox.ItemsSource = ser.portsList;
                    comboBox.ItemsSource = ser.Getportnames();
                    if (ser.serial.IsOpen)
                    {
                        ser.serial.Close();
                    }
                    if (comboBox.SelectedItem.ToString() == "NONE")
                    {
                        comboBox.Background = Brushes.Yellow;
                        comboBox.Foreground = Brushes.DarkRed;
                    }
                    else
                    {
                        ser.serial.PortName = (string)comboBox.SelectedItem;
                        ser.serial.Open();
                        comboBox.Background = Brushes.Green;
                        comboBox.Foreground = Brushes.DarkGreen;
                    }
                    /*
                    if (!ser.serial.IsOpen)
                    {
                        ser.serial.PortName = (string)comboBox.SelectedItem;
                        ser.serial.Open();
                        comboBox.Background = Brushes.Green;
                        comboBox.Foreground = Brushes.DarkGreen;
                    }
                    else
                    {
                        ser.serial.Close();
                        comboBox.Background = Brushes.Yellow;
                        comboBox.Foreground = Brushes.DarkRed;
                    }
                    */
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }

        }

        private void ComboRates_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            try
            {
                if (ser.BOPEN)
                {
                    ser.serial.BaudRate = bauds[ComboRates.SelectedIndex];
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }

        }

        private void Parities_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            try
            {
                if (ser.BOPEN)
                {
                    switch (ComboParities.SelectedIndex)
                    {
                        case 0:
                            ser.serial.StopBits = StopBits.One;
                            ser.serial.Parity = Parity.Odd;
                            break;
                        case 1:
                            ser.serial.StopBits = StopBits.One;
                            ser.serial.Parity = Parity.Even;
                            break;
                        case 2:
                            ser.serial.StopBits = StopBits.Two;
                            ser.serial.Parity = Parity.None;
                            break;
                        case 3:
                            ser.serial.StopBits = StopBits.One;
                            ser.serial.Parity = Parity.None;
                            break;

                        default:
                            break;

                    }

                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }


        }

    }
  

}
