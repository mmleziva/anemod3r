#include "scheduler.h"
#define STEPS 10;  //10ms scheduler cycle

uint8_t Step;

void TMR6_callback(uint32_t status, uintptr_t context); 

//schedule initialization registers after reset
inline void schedini(void)
{
 TMR6_CallbackRegister(TMR6_callback,(uintptr_t)NULL);//Harmony pheriph.func.   
 TMR6_Start();//Harmony pheriph.func.  
 //VOLT= true; //!!!test!!!analog 
}

//1ms schedule timer 
void TMR6_callback(uint32_t status, uintptr_t context)
{    
     WDTCONbits.WDTCLRKEY=0x5743;
    switch(Step)
    {          
        case(8):
           LED1_Toggle();//test
           if(!VOLT)
           {
                NOCHANGE= true;
                calc();                
            }
            else 
                if(!CONTA)
                    StartAD();
            break;
        default: 
            break;
             
    }
    Step++;
    Step %= STEPS;
    modrec();//modbus com.
}
