
#ifndef _CALCULATION_H    /* Guard against multiple inclusion */
#define _CALCULATION_H
#include "definitions.h"
#include "anals.h"
#include <math.h>
#include <stdio.h>
#define TRIGPER (PR5+1) //ADC trigger timer
#define STARTPAUSE 60  //PAUSE AT THE BEGINNING BEFORE MEASUREMENT 
//#define NPACK 25  
#define NPACK 15  
extern char rxData;
void inicalc(void);
void calc(void);
extern const float Kfilfl;
extern const float Lxfl;
extern bool RESX, RESY;
#endif /*_CALCULATION_H*/
