#include "mb_interf.h"
bool TEMPBLOCK;
bool VOLT,NEUTRAL,DENULL,SILENT,START;
FLUI *pLx,*pKfil,*pLred,*pLac;    //pointer to float 
//FLUI *pT;
FLUI *const pT=  (FLUI *)&INPREGS[2];
FLUI *pA,*pAca;
uint8_t COMMAND, *ptrCOMMAND, inc;
float Lred[NREC];//Lred- set values  
FLUI Kfil, Lx, Lxo;
bool RESX, RESY;
uint16_t mj;
bool NOCHANGE,ANAC,CONTA;
//const float  __attribute__((aligned(0x4000))) Lredfl[0x1000]= {(LDIST+SHIFT),(LDIST+SHIFT),(LDIST+SHIFT),(LDIST+SHIFT),LDIST,1};//t   
const float  __attribute__((aligned(0x4000))) Lredfl[0x1000]= {0,0,0,0,LDIST,1};//t   

void flashread(void)
{
    RESY= NVM_Read( (uint32_t *) Lred, (4*4), (uint32_t)Lredfl );
    RESY= NVM_Read(  &Lx.u, 4, (uint32_t)(Lredfl+4) );
    RESY= NVM_Read(  &Kfil.u, 4, (uint32_t)(Lredfl+5));
}

void flashwrite(void)
{
    RESX= NVM_PageErase( (uint32_t)Lredfl);//t
    while(NVM_IsBusy());
    RESX= false;
    RESX=NVM_QuadWordWrite((uint32_t*) Lred, (uint32_t)Lredfl);
    while(NVM_IsBusy());
    RESX= false;
    RESX= NVM_WordWrite( Lx.u, (uint32_t)(Lredfl+4));
    while(NVM_IsBusy());
    RESX= false;
    RESX= NVM_WordWrite(Kfil.u,(uint32_t)(Lredfl+5));
    while(NVM_IsBusy());
 }
;
void conf_interf(void)
{
     pLx=  (FLUI *)&HOLDREGSR[2];     
     pKfil=(FLUI *)&HOLDREGSR[4];
     pLred=  (FLUI *)&HOLDREGSR[6];
     ptrCOMMAND=&(HOLDREGSR[0].L);
    // pT=  (FLUI *)&INPREGS[2];
     pA=   (FLUI *)&INPREGS[6];
     *pLx= Lx;
     Lxo= Lx;//t
     *pKfil= Kfil;
     pLac=pLred;
     for(mj=0; mj<NREC;mj++)
     {
         pLac->f=Lred[mj];
         pLac++;
     }
     
     cfgModbus();
     
}
void mwend(void)
{
   if(mbs.funCode == 0x4)
   {     
      if(mbs.startAdr.W == (ADR0INPREG+SAMPSTER+ADRANA))//t
      {
          NOCHANGE= true;
      }
      else
      if(mbs.startAdr.W == (ADR0INPREG + ((NREC-1)*SAMPSTER + ADRANA)))
      {
          NOCHANGE= false;
          CONTA= false;
      }
   }
}


void interf (void)
{     
 if(mbs.received)
 {
  mbs.received= false;
  switch(mbs.funCode)
  {   
    
    case 0x3:
     {
        mj++;//t
     }
     break; 
 
     case 0x4:
     {
      if(mbs.startAdr.W == (ADR0INPREG+ADRANA))
      {
          NOCHANGE= true;
      }
      else if(mbs.startAdr.W == (ADR0INPREG+SAMPSTER+ADRANA))//t
      {
          NOCHANGE= true;
      }
     }
     break;
    case 0x10:
    {
    if(mbs.startAdr.W != ADR0HOLDREG)
    {
     Lx.f= pLx->F;
  //   ph0= (Lx.f)/(c*TrigPer); //standard absolute phase //t
     Kfil.f= pKfil->F;
     for(inc=0; inc< NREC; inc ++)
     {       
      Lred[inc]=  (pLred+inc)->F;
     }
     flashwrite();
    }
    else
    {
     COMMAND= *ptrCOMMAND;
      switch(COMMAND)
      {
        case 'b':
             TEMPBLOCK= true;//block temp meas.
        break;
        case 'a':
             TEMPBLOCK= false;//enable temp. meas.
        break;
        case 'u':
             VOLT= true;
             SILENT= false;
             START= false;  
             CONTA=false;   //t
            // NOCHANGE= false;//t
             NOCHANGE= true;//t
             OCMP1_Enable ();
             OCMP2_Enable ();
        break;
        case 'v':
             VOLT= false;
             SILENT= false;
             START= false;
             CONTA=false;   //t
            // NOCHANGE= true;//t
              NOCHANGE= false;//t
           //  TMR2_Start();  //40kHz  
             OCMP1_Enable ();
             OCMP2_Enable ();
        break;
        case 'n':
             NEUTRAL= true;//receives self-test command
        break;
        case 'd':
             DENULL= true;//receives reset parameters command
        break;
        case 's':  
            VOLT= true;
            if(!SILENT)
            {
             SILENT= true;
             START= false;
            }
            else
            {
                SILENT= false;
                START= true;
            }
             break;
            
        default:
        break;
      }
      COMMAND=0;    
    }
   }
  }
 }
}