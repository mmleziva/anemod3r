#include "mb_interf.h"
bool TEMPBLOCK;
bool VOLT,NEUTRAL,DENULL,SILENT,START;
float * const pLx= (float *)&HOLDREGSR[2];    //pointer to float 
float * const pKfil=(float *)&HOLDREGSR[4];    //pointer to float 
float *const pLred= (float *)&HOLDREGSR[6];    //pointer to float 
float *const pT=  (float *)&INPREGS[2];
float *const pA=   (float *)&INPREGS[6];
uint8_t COMMAND, *ptrCOMMAND, inc;
float Lred[NREC];//Lred- set values  
float Kfil;
FLUI Kuf,Luf;
float Lx, Lxo;
bool RESX, RESY;
uint16_t mj;
bool NOCHANGE,ANAC,CONTA;
const float  __attribute__((aligned(0x4000))) Lredfl[0x10]= {0,0,0,0,LDIST,1};//t   

void flashread(void)
{
    RESY= NVM_Read( (uint32_t *) Lred, (4*4), (uint32_t)Lredfl );
    RESY= NVM_Read(  &Luf.u, 4, (uint32_t)(Lredfl+4) );
    Lx= Luf.f;
    RESY= NVM_Read(  &Kuf.u, 4, (uint32_t)(Lredfl+5));
    Kfil= Kuf.f;
}

void flashwrite(void)
{
    RESX= NVM_PageErase( (uint32_t)Lredfl);//t
    while(NVM_IsBusy());
    RESX= false;
    RESX=NVM_QuadWordWrite((uint32_t*) Lred, (uint32_t)Lredfl);
    while(NVM_IsBusy());
    RESX= false;
    Luf.f= Lx;
    RESX= NVM_WordWrite( Luf.u, (uint32_t)(Lredfl+4));
    while(NVM_IsBusy());
    RESX= false;
    Kuf.f= Kfil;
    RESX= NVM_WordWrite(Kuf.u,(uint32_t)(Lredfl+5));
    while(NVM_IsBusy());
 }
;
void conf_interf(void)
{
      ptrCOMMAND=&(HOLDREGSR[0].L);
      *pLx= Lx;
      Lxo= Lx;//t
      *pKfil= Kfil;
      for(mj=0; mj<NREC;mj++)
     {
          pLred[mj]= Lred[mj];
     }
     
     cfgModbus();
     
}
void mwend(void)
{
   if(mbs.funCode == 0x4)
   {     
      if(mbs.startAdr.W == (ADR0INPREG+SAMPSTER+ADRANA))//t
      {
  //        NOCHANGE= true;
      }
      else
      if(mbs.startAdr.W == (ADR0INPREG + ((NREC-1)*SAMPSTER + ADRANA)))
      {
          NOCHANGE= false;
          //CONTA= false;
      }
   }
}


void interf (void)
{     
 if(mbs.received)
 {
  mbs.received= false;
  switch(mbs.funCode)
  {   
    
    case 0x3:
     {
        mj++;//t
     }
     break; 
 
     case 0x4:
     {
      if(mbs.startAdr.W == (ADR0INPREG+ADRANA))
      {
//          NOCHANGE= true;
      }
      else if(mbs.startAdr.W == (ADR0INPREG+SAMPSTER+ADRANA))//t
      {
          NOCHANGE= true;//t
      }
     }
     break;
    case 0x10:
    {
    if(mbs.startAdr.W != ADR0HOLDREG)
    {
     Lx= *pLx;
     Kfil= *pKfil;
     for(inc=0; inc< NREC; inc ++)
     {       
         Lred[inc]=  pLred[inc];
     }
     flashwrite();
    }
    else
    {
     COMMAND= *ptrCOMMAND;
      switch(COMMAND)
      {
        case 'b':
             TEMPBLOCK= true;//block temp meas.
        break;
        case 'a':
             TEMPBLOCK= false;//enable temp. meas.
        break;
        case 'u':
             VOLT= true;
             SILENT= false;
             START= false;  
 //            CONTA=false;   //t
//             NOCHANGE= true;//t
             OCMP1_Enable ();
             OCMP2_Enable ();
        break;
        case 'v':
             VOLT= false;
             SILENT= false;
             START= false;
 //            CONTA=false;   //t
               NOCHANGE= false;//t
           //  TMR2_Start();  //40kHz  
             OCMP1_Enable ();
             OCMP2_Enable ();
        break;
        case 'n':
             NEUTRAL= true;//receives self-test command
        break;
        case 'd':
             DENULL= true;//receives reset parameters command
        break;
        case 's':  
            VOLT= true;
            NOCHANGE= false;
            if(!SILENT)
            {
             SILENT= true;
             START= false;
            }
            else
            {
                SILENT= false;
                START= true;
            }
            break;            
        default:
        break;
      }
      COMMAND=0;    
    }
   }
  }
 }
}