
#ifndef _ANAFUN_H    /* Guard against multiple inclusion */
#define _ANAFUN_H
#include "definitions.h"
typedef struct
{
   float ph1;//phases of voltage transition to zero, 
   float pha;//phases of voltage transition to zero,      
   float Amp;// amplitude  of the sine signal 
   float dAmp;//offset of the sine signal 
}harm;
extern int wh,ww,nt;
void iniAnafun(void);
bool aver(int16_t *p, harm *ph);
float LeastSquarts(int16_t *p, harm *ph);
float searchana(int16_t *p);
#endif /* _ANAFUN_H*/
