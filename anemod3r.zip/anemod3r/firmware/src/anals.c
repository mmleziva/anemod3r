
#include "anals.h"
int16_t ijk,nn;
uint16_t ja, setdelay=10, aj;
//uint32_t sumter;
uint32_t auxstat;
bool  SILCONT, STACONT;
bool TBUFUL ;
uint16_t *ptrAna;
#define NCANALS 3    
#define NR 7  //SAMPS=2^NR  

int16_t adcdma[NCANALS][2 * 128];
uint8_t ndma[2 * NCANALS]; //actual pointers in adcdma

void ADMApreset(void) {
    ADCDMAB = KVA_TO_PA((uint32_t) &adcdma); ; //adma addressing and turn virtual to physical memory
    ADCCNTB = KVA_TO_PA((uint32_t) &ndma);
}

inline void StartAD(void) 
{
   WDTCONbits.WDTCLRKEY = 0x5743;
   {     
       
    if (!SILENT)SILCONT = false;    //stop transmit zoom- not important 
    if (!START) STACONT = false;    //start transmit zoom- not important 
    if (!SILCONT && !STACONT && !CONTA)  //t
    {
        CONTA= true;                //measurement is in progress
        if (SILENT || START)
        {
            LED2_Set();
            ADCCON3bits.CONCLKDIV = 6;
        }
        ADCDSTATbits.DMAEN = 1; //t
        ADCDSTATbits.DMACEN = 1; //count enable
        ADCHS_ModulesEnable(ADCHS_MODULE0_MASK | ADCHS_MODULE1_MASK | ADCHS_MODULE2_MASK );
        TBUFUL = true;
    }
   } 
} 

inline void StopAD(void) 
{
    LED2_Clear();//t
// /* unimportant start and stop transmitting    
    if (SILENT && !SILCONT)//if stop transmit command
    {
        ADCCON3bits.CONCLKDIV = 0;
        SILCONT = true;
        ijk= -1;
    }
    else if (START && !STACONT) //if start transmit command
    {
         ADCCON3bits.CONCLKDIV = 0;
         STACONT = true;
          ijk= -1;
    }
   // if(!NOCHANGE)
    {
     if(!NOCHANGE)
     {
        ptrAna= (uint16_t *) &(INPREGS[ADRANA].W);
        for (ja = 0; ja < (SAMPSTER); ja++)
        {
           for (bj = 0; bj < NREC; bj++)
           {
             *ptrAna= adcdma[bj][ja];
              ptrAna++;
           }
        }
        if (VOLT)
            NOCHANGE= true;
        
     }
      //NOCHANGE= true;
    }
    for (ja = 0; ja < (2 * NCANALS); ja++)//reset ADC DMA
        ndma[ja] = 0;
    if (VOLT) //t
    {   //sine graph 
         CONTA=false;
      //   if(!NOCHANGE)  //t      
         if(!NOCHANGE && !SILCONT && !STACONT)  //t       
           StartAD();//t
    }
    else    //speed graph
     evaluate(); //SELFTEST.c
 }

void ADC_DMA_InterruptHandler(void) {
 //   EVIC_SourceStatusClear(INT_SOURCE_ADC_DMA);//ADC interrupt clear
    TMR5_Stop();
 //   LED2_Clear();//t
    ADCDSTATbits.DMAEN = 0; //t
    ADCDSTATbits.DMACEN = 0; //count enable    
    ADCHS_ModulesDisable(ADCHS_MODULE0_MASK | ADCHS_MODULE1_MASK | ADCHS_MODULE2_MASK );
    auxstat=ADCDSTAT;
    EVIC_SourceStatusClear(INT_SOURCE_ADC_DMA);//ADC interrupt clear
    StopAD();
};

void __ISR(_ADC_DMA_VECTOR, ipl1SOFT) ADC_DMA_Handler (void)
{
    ADC_DMA_InterruptHandler();
}


void TMR2_callback(uint32_t status, uintptr_t context)//40kHz timer
{
    WDTCONbits.WDTCLRKEY=0x5743;
   
    if (TBUFUL) 
    {
//   unimportant start and stop transmitting
        if (SILENT && !SILCONT)
        {
            nt++;
            if (nt < setdelay) {
                OCMP1_Disable();
                OCMP2_Disable();
            }
            else
            {
                nt = 0;
                TBUFUL = false;
            }
        }
        else if (START)
        {
            nt++;
            if (nt < setdelay)
            {
                OCMP1_Enable();
                OCMP2_Enable();
            }
            else
            {
                nt = 0;
                TBUFUL = false;
            }
        }
        else          
        {
            nt = 0;
            TBUFUL = false;
        }
        if (!TBUFUL)
        {
            TMR5_Start(); //ADC trigger
     //       Tset= TMR2;
 //           LED2_Set(); //t
        }
    }

     ADCHS_ChannelConversionStart(ADCHS_CH7); //ntc temp.

}

inline void iniAnals(void) {
    ADC0TIMEbits.BCHEN = 1; //enable buffer
    ADC1TIMEbits.BCHEN = 1; //enable buffer
    ADC2TIMEbits.BCHEN = 1; //enable buffer
    ADCCON1bits.DMABL = NR; //buffer bit length
    ADCDSTATbits.RAFIEN0 = 1; //DMA buffer A full interrupt enable
    ADCDSTATbits.RAFIEN1 = 1; //DMA buffer A full interrupt enable
    ADCDSTATbits.RAFIEN2 = 1; //DMA buffer A full interrupt enable
    ADCDSTATbits.RBFIEN0 = 1; //DMA buffer B full interrupt enable
    ADCDSTATbits.RBFIEN1 = 1; //DMA buffer B full interrupt enable
    ADCDSTATbits.RBFIEN2 = 1; //DMA buffer B full interrupt enable
    ADCFLTR4bits.CHNLID = 17; //ADC4 module filter(of NTC)
    ADCFLTR4bits.DATA16EN = 1; // 16bit data
    ADCFLTR4bits.OVRSAM = 3; //256 samples filter
    ADCFLTR4bits.AFEN = 1;
    EVIC_SourceEnable(INT_SOURCE_ADC_DMA); //
    IPC26bits.AD1FCBTIP = 1; //ADC_DMA interrupt priority  
    IPC26bits.AD1FCBTIS = 3;//3; //ADC_DMA interrupt subpriority  
    TMR2_CallbackRegister(TMR2_callback, (uintptr_t) NULL);
    TMR2_Start();//t
    iniAnafun();
 }


