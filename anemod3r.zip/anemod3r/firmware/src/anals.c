
#include "anals.h"
uint16_t ja;
uint32_t auxstat;
bool TBUFUL ;
uint16_t *ptrAna;
#define NCANALS 3    
#define NR 7  //SAMPS=2^NR  

int16_t adcdma[NCANALS][2 * 128];
uint8_t ndma[2 * NCANALS]; //actual pointers in adcdma

void ADMApreset(void) {
    ADCDMAB = KVA_TO_PA((uint32_t) &adcdma); ; //adma addressing and turn virtual to physical memory
    ADCCNTB = KVA_TO_PA((uint32_t) &ndma);
}

inline void StartAD(void) 
{
   WDTCONbits.WDTCLRKEY = 0x5743;
   {     
    if (!CONTA)  //ADC finished and start enable
    {
        CONTA= true;                //measurement is in progress
        ADCDSTATbits.DMAEN = 1; //t
        ADCDSTATbits.DMACEN = 1; //count enable
        ADCHS_ModulesEnable(ADCHS_MODULE0_MASK | ADCHS_MODULE1_MASK | ADCHS_MODULE2_MASK );
        TBUFUL = true;//TMR2 will start ADC
    }
   } 
} 

inline void StopAD(void) 
{
    LED2_Clear();//t
    {
     if(!NOCHANGE)
     {                                          //sample of one wavelenght  
        ptrAna= (uint16_t *) &(INPREGS[ADRANA].W);//pointer to modbus register
        for (ja = 0; ja < (SAMPSTER); ja++)
        {
           for (bj = 0; bj < NREC; bj++)
           {
             *ptrAna= adcdma[bj][ja];
              ptrAna++;
           }
        }
        if (VOLT)               //if sine graph
            NOCHANGE= true;     //no change sample till being read 
        
      }
    }
    for (ja = 0; ja < (2 * NCANALS); ja++)//reset ADC DMA
        ndma[ja] = 0;
    if (VOLT) //t
    {   //sine graph 
         CONTA=false; //ADC enable    
         if(!NOCHANGE)  //change of samples is not disable
           StartAD();//t
    }
    else    //speed graph
     evaluate(); //in SELFTEST.c
 }

void ADC_DMA_InterruptHandler(void) {
    TMR5_Stop();
    ADCDSTATbits.DMAEN = 0; //t
    ADCDSTATbits.DMACEN = 0; //count enable    
    ADCHS_ModulesDisable(ADCHS_MODULE0_MASK | ADCHS_MODULE1_MASK | ADCHS_MODULE2_MASK );
    auxstat=ADCDSTAT;
    EVIC_SourceStatusClear(INT_SOURCE_ADC_DMA);//ADC interrupt clear
    StopAD();
};

void __ISR(_ADC_DMA_VECTOR, ipl1SOFT) ADC_DMA_Handler (void)
{
    ADC_DMA_InterruptHandler();
}


void TMR2_callback(uint32_t status, uintptr_t context)//40kHz timer for transmitter 
{
    WDTCONbits.WDTCLRKEY=0x5743;
  
    if (TBUFUL) 
    {
       TMR5_Start(); //ADC trigger
       TBUFUL = false;
    }
    ADCHS_ChannelConversionStart(ADCHS_CH7); //ntc temp.

}

inline void iniAnals(void) {
    ADC0TIMEbits.BCHEN = 1; //enable buffer
    ADC1TIMEbits.BCHEN = 1; //enable buffer
    ADC2TIMEbits.BCHEN = 1; //enable buffer
    ADCCON1bits.DMABL = NR; //buffer bit length
    ADCDSTATbits.RAFIEN0 = 1; //DMA buffer A full interrupt enable
    ADCDSTATbits.RAFIEN1 = 1; //DMA buffer A full interrupt enable
    ADCDSTATbits.RAFIEN2 = 1; //DMA buffer A full interrupt enable
    ADCDSTATbits.RBFIEN0 = 1; //DMA buffer B full interrupt enable
    ADCDSTATbits.RBFIEN1 = 1; //DMA buffer B full interrupt enable
    ADCDSTATbits.RBFIEN2 = 1; //DMA buffer B full interrupt enable
                              // NTC 
    ADCFLTR4bits.CHNLID = 17; //ADC4 module filter
    ADCFLTR4bits.DATA16EN = 1; // 16bit data
    ADCFLTR4bits.OVRSAM = 3; //256 samples filter
    ADCFLTR4bits.AFEN = 1;
    
    EVIC_SourceEnable(INT_SOURCE_ADC_DMA); //
    IPC26bits.AD1FCBTIP = 1; //ADC_DMA interrupt priority  
    IPC26bits.AD1FCBTIS = 3; //ADC_DMA interrupt subpriority  
    TMR2_CallbackRegister(TMR2_callback, (uintptr_t) NULL);
    TMR2_Start();//t
    iniAnafun();
 }


