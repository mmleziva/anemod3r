#include "SELFTEST.h"
//#define DEBUG   //test deb
#define ADCONST (1650.0/2048.0)//(3300/2)mV/ (0x1000/2)bit 
#define AMPMIN 0x10         //minimal amplitude
//#define DIFMAX 0.25         //repaired
#define DIFMAX 0.1         //max. allowed difference in no wind (0.1mm~ 0.57m/s)
uint16_t  bj, NS,pau;
volatile uint16_t NSxa;
float ph[NREC],A[NREC];
float phred[NREC],aph[NREC],aphav[NREC],phc,phd;
float dphxav,dphyav;
float Sdphxa,Sdphya;    //sums
float Saph[NREC],Sph[NREC];
 float *ptrLr; 
harm h[NREC];
bool  SELFTE, OK[NREC],FAMP[NREC],CORTEST;
bool FIL[NREC];
float aphfil[NREC];
uint16_t ks,ih;
float Lr[NREC];// Lr - measured values 
float T;
float TrigPer;//trigger period
float c;
float ph0;
uint16_t Tset;
#ifdef DEBUG
float fad[NREC][SAMPLES];
#endif
void correct(bool *OKO)//an example of function - its results not used in this program
{//4 x distances Lred (received by serial) are compared with the last measured distances Lr 
     for(bj=0;bj<NREC;bj++)
     {        
       Lr[bj]= aphav[bj] * TrigPer *c;//average recalculated routes [mm]  
       OKO[bj]= abs(Lr[bj]-Lred[bj])< DIFMAX;  
     }
}


//simple dig. Filter(pointer to input value, filtered value, initial zero bit)
void Filter(float *pv, float *pfil, bool *pBEGIN)
{
  bool FAUX; 
  FAUX= (Kfil.f > 0) && (Kfil.f < 1);
  
  if( FAUX && *pBEGIN) //continuous filtering 
  {
      *pfil= *pfil+ Kfil.f  * (*pv-*pfil);
      *pBEGIN= true;
  }
  else if(FAUX)     //start filtering
  {
    *pBEGIN= true;
    *pfil= *pv;
  }
  else      
  {     //unexpected filter constant 
      *pfil= *pv;
  }
  
}


void averval(float *phfil)//called from calculation.c , fills average phases diff.
{
    
   for(ks=0; ks< NREC; ks++)
   {   
     aphav[ks]= Saph[ks]/NSxa;
     Saph[ks]=0;
   }
   if(CORTEST)// in sericom.c after receiving a zero speed wind correction 
   {
       CORTEST= false;
        correct(OK);        //fills the bit array "OK"
   }     
   NSxa=0;
   //NSya=0;
   for(ks=0; ks< NREC; ks++)
   {
     Filter(&aphav[ks],&aphfil[ks],&FIL[ks]);
   //  phfil[ks]= aphfil[ks]-phred[ks];//corrected phase diff.= measured phase diff.- zero speed wind phase diff.
     phfil[ks]= aphfil[ks];//t
   }
}

void pardal(void)
{
    pAca= pA;
    for(ih=0; ih< NREC; ih++)
    {
                 A[ih]=  h[ih].Amp * ADCONST;
                  pAca->f= A[ih];
                  pAca++;
    }
    pT->f=T-273.15; 
  //*pT.f=T-273.15;     
}

void selftest(void)//one pass of self test cycle, called from evaluate()
{
                                //measurement evaluation
              SELFTE= false;    //reset self test request bit
              pau= SELFPAUSE;//t
              pLac=pLred;
              for(bj=0;bj<NREC;bj++)// NREC receivers
              {
                  phc= aphfil[bj]-ph0;
                  if(phc > 0)
                  {
                   while(phc> wh )//set the measured phase phc closest to the  calculated phase ph0                              
                    phc -= ww;                   
                  }
                  else if(phc < 0)
                  {
                   while(phc< -wh )//set the measured phase phc closest to the  calculated phase ph0                              
                    phc += ww;
                  }
                  aphfil[bj]= ph0+ phc;
                  Lr[bj]= aphfil[bj] * TrigPer *c;//average recalculated routes [mm]
                  pLac->f= Lr[bj];
                  pLac++;
                //  NS=0;
               //  CONTA= false;            
              }
              CONTA= false;       
}

inline void evaluate(void)    //processes values of one ultrasound period , called from anals.c: stopAD() 
{
        for (bj = 0; bj < NREC; bj++) 
        {
         FAMP[bj]=aver(adcdma[bj],&h[bj]);//function anafun.c: aver(adcdma,&h) fill the struct h with the amplitude and phase of the wave "adcdma" 
      //   if(h[bj].Amp < AMPMIN)
         ph[bj]=LeastSquarts(adcdma[bj],&h[bj]);//precisionize by the least square method 
         ph[bj] += (float)Tset/(PR5+1);//start delay correction (due to the difference is unnecessary) 
        }
        if(SELFTE)              //set after selftest request in calculation.c
        {                      //self test counts average values of distances and amplitudes             
            selftest();
        }
        else             
        {                              //usual phases measurement
          IPC19CLR = 0x8 ;  /* TIMER_6:  Priority 0 / Subpriority 3 */
          for (bj = 0; bj < NREC; bj++) 
          {
           
              phd= ph[bj];
              while((phred[bj]- phd) > wh)//(.. > half wave)
              {             //search for the nearest zero speed wind phase 
                phd += ww;  //(+= whole wave)     
              }
              aph[bj]=phd;  //absolute phase distance from transmitter to receiver + receiver phase delay
              #ifdef DEBUG
                fad[bj][NSxa]= aph[bj];
              #endif
              Saph[bj] += aph[bj];
          }   
          NSxa++;
          IPC19SET = 0x8 ;  /* TIMER_6:  Priority 2 / Subpriority 3 */
          if((NSxa< SAMPLES))
          {     
           CONTA= false;
           StartAD();//t
          }
          else
           CONTA= false;  
       }
}