
#ifndef _ANALS_H    /* Guard against multiple inclusion */
#define _ANALS_H
#include "SELFTEST.h"
//#include "anafun.h"
#define SAMPSTER 100
//#define SAMPS 128
#define ADRANA 20
#define ADRVEL (NREC*SAMPSTER +ADRANA)
extern int16_t dad[NREC][SAMPS];
void ADMApreset(void);
void iniAnals(void);
//void StartAD(void);
void StopAD(void);
extern uint16_t setdelay;
extern uint16_t Tset;
#endif /* _ANALS_H */
