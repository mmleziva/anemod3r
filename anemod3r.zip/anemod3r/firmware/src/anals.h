
#ifndef _ANALS_H    /* Guard against multiple inclusion */
#define _ANALS_H
#include "SELFTEST.h"
#define ADRVEL (NREC*SAMPSTER +ADRANA)
void ADMApreset(void);
void iniAnals(void);
void StopAD(void);
extern uint16_t setdelay;
extern uint16_t Tset;
#endif /* _ANALS_H */
