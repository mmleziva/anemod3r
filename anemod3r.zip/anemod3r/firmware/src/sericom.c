#include "sericom.h"
char sync;
char rxData,rstring[SMAX+1];
short int irx,nstr;
UARTFLAGS uarf1;
bool FURT;
unsigned char bufout[BUFOUTMAX+1],bufin[BUFINMAX+1];
unsigned char  *pbufo;
void UART_WriteHandler(uintptr_t context);
void UART_ReadHandler(uintptr_t context);

//main DMA
void APP_DMA_TransferEventHandler(DMAC_TRANSFER_EVENT event, uintptr_t contextHandle)
{
    uarf1.WRITBUSY= false;
    switch(event)
    {
        case DMAC_TRANSFER_EVENT_COMPLETE:
            // This means the data was transferred.            
             LED4_Clear();
             //LED3_Clear();
             //LED1_Clear();
            //LED2_Clear();//t
             break;

        case DMAC_TRANSFER_EVENT_ERROR:
            // Error handling here.
            LED4_Clear();
            // LED1_Clear();
            // LED2_Clear();//t
            break;

        default:
            break;
    }
}

void serini()
{
 DMAC_Initialize();//t
 pbufo=&bufout[0];
 //uart harmony interrupt handlers   
    DMAC_ChannelCallbackRegister(DMAC_CHANNEL_0, APP_DMA_TransferEventHandler,(uintptr_t)NULL);
 UART1_ReadCallbackRegister( UART_ReadHandler, (uintptr_t)NULL) ;//Harmony pheriph.func.
 if(!UART1_ReadIsBusy())//Harmony pheriph.func.   
   UART1_Read(&rxData, sizeof(uint8_t ));//Harmony pheriph.func.   
 // U1STAbits.UTXISEL=0;//t
   U1STAbits.UTXISEL=2;//t
  uarf1.Fred= true;//t
}
/*
void Autos(void)
{
  Npaus++;
  if(Npaus > NP)
  {
   Npaus=0;
   uarf1.Fred= 0;  
  U1MODEbits.ABAUD = 1;	//t
  }
}

 */ 

void UART_ReadHandler(uintptr_t context)
{  
   // UART1_ErrorGet();
    if(!uarf1.Fred)
    {
     {   
     // U1TXREG= sync=0xaa;//t
     }
 }
 else
 {
  if(T4CONbits.ON == false)
  {
   uarf1.ErrPar=0;
   TMR4_Start ();
   irx=0;
  }
  TMR4 = 0;		
  if(U1STAbits.OERR)U1STAbits.OERR=0;		// Enable UART Tx 
  if(irx < BUFMAX)
  {
   rstring[irx]= rxData;    
   irx++;//number of chars received 
  }
 } 
  UART1_Read(&rxData, sizeof(uint8_t )); //wait for data to be received
}


void startU1tr(int n)//start transmit of this card data to UART1->USB 
{
 if(!uarf1.WRITBUSY)
 {
     uarf1.WRITBUSY= true;
    IFS1bits.U1TXIF= false;
    U1TXREG = bufout[0];
    FURT= DMAC_ChannelTransfer(DMAC_CHANNEL_0, (const void *)bufout, n  , (const void *)&U1TXREG, 1, 1); //Harmony pherif.func.        
    DCH0ECONbits.CFORCE = true;//transfer init manually
    LED4_Set();
    WDTCONbits.WDTCLRKEY=0x5743;
 }
} 