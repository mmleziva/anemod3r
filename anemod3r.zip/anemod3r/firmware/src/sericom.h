

#ifndef _SERICOM_H    /* Guard against multiple inclusion */
#define _SERICOM_H
#define SMAX 64
//#define SAMPSTER 100
//#define SAMPS 128
#define BUFMAX 64
#define BUFOUTMAX 256
#define BUFINMAX 64
#include <stdio.h>
#include "definitions.h"

typedef  union 
{
 unsigned char UB[2];
 unsigned short int  UI;
 unsigned char B[2];
 unsigned short int  I;
}SHORT ;

typedef  union 
{
 unsigned short int W;
 struct
 {
     unsigned char L;
     unsigned char H;
 };
}WORD;


typedef  union 
{
 uint32_t u;
 float f;
 unsigned char UB[4];
 unsigned long int UL;
 unsigned short int  UI[2];
 unsigned char B[4];
 long int L;
 short int  I[2];
 float F;
}FLUI;

typedef struct 
{
 unsigned Pre  :1; 
 unsigned Rec  :1; 
 unsigned ErrPar: 1; 
 unsigned Master: 1; 
 unsigned Uart1: 1; 
 unsigned Uart2: 1; 
 unsigned Fred:  1;
 unsigned WRITBUSY: 1;
 
}UARTFLAGS;


extern bool FURT;
void startU1tr(int n);
extern UARTFLAGS uarf1;
extern char rxData,rstring[SMAX+1];
extern short int irx,nstr;
extern unsigned char  *pbufo;
void serini();

//#include "config/basic/definitions.h"
#endif /* _SERICOM_H */

