#ifndef _MB_INTERF_H    /* Guard against multiple inclusion */
#define _MB_INTERF_H
#include "modbus.h"
#define LDIST 28  //[mm] transmitter receiver distance
#define SHIFT 1 //aproximated receivers shift [mm]
#define NREC 3   //number of receivers =4(3)
#define SAMPSTER 120
#define ADRANA 20

typedef union{
    uint32_t u;
    float f;
}uf;
void conf_interf(void);
extern FLUI Kfil, Lx;
extern FLUI *pLred,*pLac;
extern bool TEMPBLOCK;
extern bool VOLT,NEUTRAL,DENULL,SILENT,START;
extern bool NOCHANGE,ANAC,CONTA;
extern float Lred[NREC];//Lred- set values  
extern  FLUI *const pT;
extern FLUI *pA,*pAca;
void flashread(void);
void flashwrite(void);

#endif /* _MB_INTERF_H */
