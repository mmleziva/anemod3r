
#ifndef _SELFTEST_H    /* Guard against multiple inclusion */
#define _SELFTEST_H
#include "definitions.h"
#include "anafun.h"
#include "mb_interf.h"
#define SAMPLES 24    //max. number of samples during 10MS PERIOD
//#define SAMPSELF 2000 //number of samples during the self-test (for win program timing min. about 2000)
//#define SELFPAUSE 10  //pause after selftest
#define SELFPAUSE 1  //t pause after selftest
//#define SELFPARAMS 4
#define SAMPS 128
extern uint16_t  pau,bj;
extern float phred[NREC],A[NREC];
extern float dphxav,dphyav;
extern float Sdphxa,Sdphya,Sdphx0,Sdphy0;
//extern volatile uint16_t NSxa,NSya;
extern volatile uint16_t NSxa;
extern bool  SELFTE,CORTEST ;
extern float Lr[NREC];// Lr - measured values
extern float T;
extern float TrigPer;//trigger period
extern float c;
extern float ph0;
void evaluate(void);
void averval(float *aphfil);
void selftest(void);
void pardal(void);
void StartAD(void);
extern int16_t dad[NREC][SAMPS]; //t
extern uint16_t Tset;
#endif /* _SELFTEST_H */
