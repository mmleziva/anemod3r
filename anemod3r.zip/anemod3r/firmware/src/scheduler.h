
#ifndef _SCHEDULER_H    /* Guard against multiple inclusion */
#define _SCHEDULER_H 
#include "definitions.h"
#include "calculation.h"
#include <stdio.h>
#include <stdlib.h>
void schedini(void);

#endif /*_SCHEDULER_H  */

