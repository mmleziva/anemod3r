#ifndef MODBUS_H
#define	MODBUS_H
#define MBUART1
//#define MBUART2
#include "sericom.h"
#include "crc.h"
#ifdef MBUART1 
//#include "uart1Drv.h"
#endif
#ifdef MBUART2 
#include "uart2Drv.h"
#endif
extern void cfgModbus(void);
extern void modrec(void);
#define NREGS 32
#define INREGS 540
extern WORD HOLDREGSR[NREGS];
extern WORD INPREGS[INREGS];
extern  uint16_t ADR0COILS;    
extern  uint16_t ADR0DISCIN; 
extern  uint16_t ADR0INPREG; 
extern  uint16_t ADR0HOLDREG; 

typedef struct 
{
 unsigned char unitId;
 unsigned char funCode;
 WORD startAdr;
 WORD regCount;
 char byteCount;
 WORD *pdat;    
 unsigned int CRC;
 unsigned char errcode; 
 unsigned char received: 1;
 //unsigned char master: 1; 
}MODBUSTRUCT;
extern MODBUSTRUCT mbs;  //modbus structures
void TMR4_callback(uint32_t status, uintptr_t context);
void interf(void);
void mwend (void);

#endif  //MODBUS_H