#include "SELFTEST.h"
#define ADCONST (1650.0/2048.0)//(3300/2)mV/ (0x1000/2)bit 
#define AMPMIN 0x10         //minimal amplitude
uint16_t  bj, bk;
volatile uint16_t NSxa;
float ph[NREC],A[NREC], phs[WAVES],phs0[WAVES];
float phred[NREC],aph[NREC],aphav[NREC],phc,phd;
float Sdphxa,Sdphya;    //sums
float Saph[NREC],Sph[NREC];
 float *ptrLr; 
harm h[WAVES];
bool  SELFTE, FAMP[NREC],CORTEST;
bool FIL[NREC];
float aphfil[NREC];
uint16_t ks,ih;
float T;
float TrigPer;//trigger period
float c;
int16_t dad[WAVES][2 * 128];
uint16_t Tset;
extern float dt[NREC];
#ifdef DEBUG
#endif

//simple dig. Filter(pointer to input value, filtered value, initial zero bit)
void Filter(float *pv, float *pfil, bool *pBEGIN)
{
  bool FAUX; 
  FAUX= (Kfil > 0) && (Kfil < 1);
  
  if( FAUX && *pBEGIN) //continuous filtering 
  {
      *pfil= *pfil+ Kfil  * (*pv-*pfil);
      *pBEGIN= true;
  }
  else if(FAUX)     //start filtering
  {
    *pBEGIN= true;
    *pfil= *pv;
  }
  else      
  {     //unexpected filter constant 
      *pfil= *pv;
  }
  
}


void averval(float *phfil)//called from calculation.c , fills average phases 
{
    
   for(ks=0; ks< NREC; ks++)
   {   
     aphav[ks]= Saph[ks]/NSxa;
     Saph[ks]=0;
   }
    NSxa=0;
   for(ks=0; ks< NREC; ks++)
   {
     Filter(&aphav[ks],&aphfil[ks],&FIL[ks]);
     phfil[ks]= aphfil[ks];//t
   }
}

inline void pardal(void)//pop amplitudes and temp.
{
    for(ih=0; ih< NREC; ih++)
    {
                 A[ih]=  h[ih].Amp * ADCONST;
                    pA[ih]=A[ih];
    }
    *pT=T-273.15; 
 }


void selftest(void)//setting at zero wind speed, called from evaluate()
{
                                //measurement evaluation
              for(bj=0;bj<WAVES;bj++)//
              {
                       phs0[bj]=phs[bj]; 
              }
 }

inline void evaluate(void)    //processes values of one ultrasound period , called from anals.c: stopAD() 
{

    for (bk = 0; bk < 4; bk++) //t
    {
        bj=bk;
        FAMP[bj]=aver(dad[bj],&h[bj]);//function anafun.c: aver(adcdma,&h) fill the struct h with the amplitude and phase of the wave "adcdma" 
        phs[bj]=LeastSquarts(dad[bj],&h[bj]);//precisionize by the least square method 
    }
    
         bj=4;
        FAMP[bj]=aver(dad[bj],&h[bj]);//function anafun.c: aver(adcdma,&h) fill the struct h with the amplitude and phase of the wave "adcdma" 
        phs[bj]=LeastSquarts(dad[bj],&h[bj]);//precisionize by the least square method 
          bj=5;
        FAMP[bj]=aver(dad[bj],&h[bj]);//function anafun.c: aver(adcdma,&h) fill the struct h with the amplitude and phase of the wave "adcdma" 
        phs[bj]=LeastSquarts(dad[bj],&h[bj]);//precisionize by the least square method 

/*
    bk=0;
    do
    {
        bj=bk;
        FAMP[bj]=aver(dad[bj],&h[bj]);//function anafun.c: aver(adcdma,&h) fill the struct h with the amplitude and phase of the wave "adcdma" 
        phs[bj]=LeastSquarts(dad[bj],&h[bj]);//precisionize by the least square method 
        bk++;
    }
    while(bk<6);
    */
     for (bj = 0; bj < NREC; bj++) 
     {
            ph[bj]= (phs[bj+NREC]- phs0[bj+NREC])- (phs[bj]- phs0[bj]);
            dt[bj]=ph[bj]*TrigPer;
     }
  

  }