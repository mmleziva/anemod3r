#ifndef _MB_INTERF_H    /* Guard against multiple inclusion */
#define _MB_INTERF_H
#include "modbus.h"
#define LDIST 28  //[mm] transmitter receiver distance
#define SHIFT 1 //aproximated receivers shift [mm]
#define NREC 3   //number of receivers =1
#define WAVES (2*NREC)
#define SAMPSTER 120
#define ADRANA 20

typedef union{
    uint32_t u;
    float f;
}uf;
void conf_interf(void);
extern float Kfil;
extern float Lx,Lxo;
extern float *const pKfil;
extern float *const pLx;
extern float *const pLred;
extern bool TEMPBLOCK;
extern bool VOLT,NEUTRAL,DENULL;
extern bool NOCHANGE,ANAC,CONTA;
extern float Lred[NREC];//Lred- set values  
extern  float *const pT;
extern  float  *const pA;
void flashread(void);
void flashwrite(void);

#endif /* _MB_INTERF_H */
