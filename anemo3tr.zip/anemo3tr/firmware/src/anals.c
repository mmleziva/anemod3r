
#include "anals.h"
uint16_t ja,TRANSMITTER,RECEIVER,CYCLE,OSCSTART[3] ;
uint32_t auxstat;
bool TBUFUL,FL_MES ;
uint16_t *ptrAna;
//#define NCANALS 1    
#define NR 7  //SAMPS=2^NR  
#define OS 20
#define WAVES 6

//int16_t adcdma[NCANALS][2 * 128];
int16_t adcdma[WAVES][2 * 128];
//int16_t dad[6][2 * 128];
//uint8_t ndma[2 * NCANALS]; //actual pointers in adcdma
uint8_t ndma[2]; //actual pointers in adcdma
uint16_t NCYC;

void ADMApreset(void) {
    ADCDMAB = KVA_TO_PA((uint32_t) &adcdma); ; //adma addressing and turn virtual to physical memory
    ADCCNTB = KVA_TO_PA((uint32_t) &ndma);
}

inline void StartAD(void) 
{
   WDTCONbits.WDTCLRKEY = 0x5743;
   {     
    if (!CONTA)  //ADC finished and start enable
    {
        TMR5=0;
        TMR5_Start();
        CONTA= true;                //measurement is in progress
        ADCDSTATbits.DMAEN = 1; //t
        ADCDSTATbits.DMACEN = 1; //count enable
        ADCHS_ModulesEnable( ADCHS_MODULE2_MASK );
      //  TBUFUL = true;//TMR2 will start ADC
    }
   } 
} 

inline void StopAD(void) 
{
    FL_MES= false;
   // LED2_Clear();//t
    {
     if(!NOCHANGE)
     {        
         /*
         //sample of one wavelenght  
        ptrAna= (uint16_t *) &(INPREGS[ADRANA].W);//pointer to modbus register
        for (ja = 0; ja < (SAMPSTER); ja++)
        {
           for (bj = 0; bj < NREC; bj++)
           {
             *ptrAna= adcdma[bj][ja];
              ptrAna++;
           }
        }
          */ 
        /*
        if (VOLT)               //if sine graph
            NOCHANGE= true;     //no change sample till being read
         * */ 
        switch(CYCLE)
        {
            case 0:
                NCYC=0;//0->1
                break;
            case 1:
                NCYC=5;//0->2
                break;
            case 2:
                NCYC=2;//1->2
                break;
            case 3:
                NCYC=1;//1->0
                break;
            case 4:
                NCYC=4;//2->0
                break;
            case 5:
                NCYC=3;//2->1
                break;
            default:
                break;
        }
        
        for (ja = 0; ja < (SAMPSTER); ja++)
        {
           
             dad[NCYC][ja]= adcdma[0][ja];
              
        }

      }
    }
    //for (ja = 0; ja < (2 * NCANALS); ja++)//reset ADC DMA
    for (ja = 0; ja < (2); ja++)//reset ADC DMA
        ndma[ja] = 0;
    CYCLE++;
    if(CYCLE==6)
    {
        CYCLE=0;
        TBUFUL= false;
    }
    /*
    if (VOLT) //t
    {   //sine graph 
         CONTA=false; //ADC enable    
         if(!NOCHANGE)  //change of samples is not disable
           StartAD();//t
    }
    else    //speed graph
     evaluate(); //in SELFTEST.c
     */
 }

void ADC_DMA_InterruptHandler(void) {
    TMR5_Stop();
    ADCDSTATbits.DMAEN = 0; //t
    ADCDSTATbits.DMACEN = 0; //count enable    
    ADCHS_ModulesDisable( ADCHS_MODULE2_MASK );
    auxstat=ADCDSTAT;
    EVIC_SourceStatusClear(INT_SOURCE_ADC_DMA);//ADC interrupt clear
    StopAD();
};

void __ISR(_ADC_DMA_VECTOR, ipl1SOFT) ADC_DMA_Handler (void)
{
    ADC_DMA_InterruptHandler();
}

void Y1_callback( uintptr_t context)
{
    OSCSTART[0]--;
    if(OSCSTART[0]==0)
        StartAD();
}
void Y2_callback( uintptr_t context)
{
    OSCSTART[1]--;
    if(OSCSTART[1]==0)
        StartAD();
}

void Y3_callback( uintptr_t context)
{
    OSCSTART[2]--;
    if(OSCSTART[2]==0)
        StartAD();
}

void TMR2_callback(uint32_t status, uintptr_t context)//40kHz timer for transmitter 
{
    WDTCONbits.WDTCLRKEY=0x5743;
  
    if (TBUFUL  && !FL_MES) 
    {
    //   TMR5_Start(); //ADC trigger
    //   TBUFUL = false;
     //  ADCDMAB = KVA_TO_PA((uint32_t) &adcdma[CYCLE]);  //adma addressing and turn virtual to physical memory
       FL_MES= true;
       switch(CYCLE)
       {
           case 0:
               OSCSTART[0]= OS;
               TRANSMITTER=0;
               RECEIVER=1;
               break;
           case 1:
               OSCSTART[0]= 1;
               TRANSMITTER=0;
               RECEIVER=2;
               break;
           case 2:
               OSCSTART[1]= OS;
               TRANSMITTER=1;
               RECEIVER=2;
               break;
           case 3:
               OSCSTART[1]= 1;
               TRANSMITTER=1;
               RECEIVER=0;
               break;
           case 4:
               OSCSTART[2]= OS;
               TRANSMITTER=2;
               RECEIVER=0;
               break;
           case 5:
               OSCSTART[2]= 0;
               TRANSMITTER=2;
               RECEIVER=1;
               break;
               
       }
       switch(RECEIVER)
       {
           case 0:
               MUL_A_Clear();
               MUL_B_Clear();              
               break;
           case 1:
               MUL_A_Clear();
               MUL_B_Set();  
               break;
           case 2:
               MUL_A_Set();
               MUL_B_Clear();
               break;
           default:
               break;
       }
       switch(TRANSMITTER)
       {
           case 0:
               OCMP1_Enable ();
               OCMP2_Enable ();
               OCMP13_Disable ();
               OCMP14_Disable ();
               OCMP7_Disable ();
               OCMP6_Disable ();
               break;
           case 1:
               OCMP1_Disable ();
               OCMP2_Disable ();
               OCMP13_Enable ();
               OCMP14_Enable ();
               OCMP7_Disable ();
               OCMP6_Disable ();
               break;
           case 2:
               OCMP1_Disable ();
               OCMP2_Disable ();
               OCMP13_Disable ();
               OCMP14_Disable ();
               OCMP7_Enable ();
               OCMP6_Enable ();
               break;
           default:
               break;
       }
    }
  //  ADCHS_ChannelConversionStart(ADCHS_CH7); //ntc temp.

}

inline void iniAnals(void) {
   
    ADC2TIMEbits.BCHEN = 1; //enable buffer
    ADCCON1bits.DMABL = NR; //buffer bit length
    ADCDSTATbits.RAFIEN2 = 1; //DMA buffer A full interrupt enable
    ADCDSTATbits.RBFIEN2 = 1; //DMA buffer B full interrupt enable
    /*
                              // NTC 
    ADCFLTR4bits.CHNLID = 17; //ADC4 module filter
    ADCFLTR4bits.DATA16EN = 1; // 16bit data
    ADCFLTR4bits.OVRSAM = 3; //256 samples filter
    ADCFLTR4bits.AFEN = 1;
    */
    EVIC_SourceEnable(INT_SOURCE_ADC_DMA); //
    IPC26bits.AD1FCBTIP = 4;    //1; //ADC_DMA interrupt priority  
    IPC26bits.AD1FCBTIS = 2;    //3; //ADC_DMA interrupt subpriority  
    TMR2_CallbackRegister(TMR2_callback, (uintptr_t) NULL);
    OCMP2_CallbackRegister(Y1_callback, (uintptr_t) NULL);
    OCMP14_CallbackRegister(Y2_callback, (uintptr_t) NULL);
    OCMP6_CallbackRegister(Y3_callback, (uintptr_t) NULL);
    iniAnafun();
 }


