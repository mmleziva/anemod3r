
#ifndef _SELFTEST_H    /* Guard against multiple inclusion */
#define _SELFTEST_H
#include "definitions.h"
#include "anafun.h"
#include "mb_interf.h"
#define SAMPLES 32   //t max. number of samples during 10MS PERIOD
#define SELFPAUSE 1  //t pause after selftest
#define SAMPS 128
extern uint16_t  pau,bj;
extern float phred[NREC],A[NREC];
extern float dphxav,dphyav;
extern float Sdphxa,Sdphya,Sdphx0,Sdphy0;
extern volatile uint16_t NSxa;
extern bool  SELFTE,CORTEST ;
extern float T;
extern float TrigPer;//trigger period
extern float c;
extern float ph0,ph0o;
void evaluate(void);
void averval(float *aphfil);
void selftest(void);
void pardal(void);
void StartAD(void);
void Lxcorrect(void);
//extern int16_t adcdma[NREC][2 * 128];
extern int16_t adcdma[][2 * 128];
extern uint16_t Tset;
extern int16_t dad[6][2 * 128];
#endif /* _SELFTEST_H */
