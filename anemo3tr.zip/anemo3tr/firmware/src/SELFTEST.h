
#ifndef _SELFTEST_H    /* Guard against multiple inclusion */
#define _SELFTEST_H
#include "definitions.h"
#include "anafun.h"
#include "mb_interf.h"
#define SAMPLES 32   //t max. number of samples during 10MS PERIOD
#define SELFPAUSE 1  //t pause after selftest
#define SAMPS 128
//extern uint16_t bj;
//extern float phred[NREC],A[NREC];
extern float A[NREC];
//extern float Sdphxa,Sdphya,Sdphx0,Sdphy0;
//extern volatile uint16_t NSxa;
extern bool  SELFTE,CORTEST ;
extern float T;
extern float TrigPer;//trigger period
extern float c;
void evaluate(void);
void selftest(void);
void resetpar(void);//reseting 
//void pardal(void);
void StartAD(void);
extern uint16_t Tset;
extern int16_t dad[WAVES][2 * 128];
#endif /* _SELFTEST_H */
